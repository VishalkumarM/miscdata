package com.gatestone.crs.messaging.spring.auth;

import org.springframework.aop.Advisor;
import org.springframework.aop.MethodMatcher;
import org.springframework.aop.Pointcut;
import org.springframework.aop.support.ComposablePointcut;
import org.springframework.aop.support.annotation.AnnotationMethodMatcher;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Role;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authorization.method.AuthorizationInterceptorsOrder;
import org.springframework.security.authorization.method.AuthorizationManagerBeforeMethodInterceptor;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

import com.gatestone.crs.messaging.spring.auth.annotations.PartialSecuredResource;
import com.gatestone.crs.messaging.spring.auth.annotations.SecuredResource;

@Configuration
@EnableMethodSecurity(prePostEnabled = false) //1
public class MethodSecurityConfig {

    public AuthorizationManagerBeforeMethodInterceptor authorizationManagerBeforeMethodInterceptor(CustomMethodAuthorizationManager customAuthorizationManager) {
        return AuthorizationManagerBeforeMethodInterceptor.preAuthorize(customAuthorizationManager);
    }
    
    @Bean
    @DependsOn("customAuthorizationManager")
    @Role(BeanDefinition.ROLE_INFRASTRUCTURE)
    @ConditionalOnProperty(name = "secure.annotation.enabled", havingValue = "true", matchIfMissing = false) // optional, default is false
    public Advisor customAuthorizationInterceptor(CustomMethodAuthorizationManager customAuthorizationManager) {
        return AuthorizationManagerBeforeMethodInterceptor.preAuthorize(customAuthorizationManager);
    }
    
    @Bean
    @DependsOn("customAuthorizationManager")
    @Role(BeanDefinition.ROLE_INFRASTRUCTURE)
    @ConditionalOnProperty(name = "secure.annotation.enabled", havingValue = "false", matchIfMissing = false) // optional, default is false
    public Advisor customAuthorizationInterceptorHttp(CustomHttpAuthorizationManager customAuthorizationManager) {
        return AuthorizationManagerBeforeMethodInterceptor.preAuthorize(customAuthorizationManager);
    }
	
    public Advisor preAuthorize1(CustomMethodAuthorizationManager customAuthorizationManager) {
        // Create pointcut for methods with either SecuredResource or PartialSecuredResource annotations
        MethodMatcher methodMatcher = new AnnotationMethodMatcher(SecuredResource.class);
        Pointcut pointcut = new ComposablePointcut(methodMatcher)
            .union(new AnnotationMethodMatcher(PartialSecuredResource.class))
            .union(new AnnotationMethodMatcher(PreAuthorize.class));
        
        // Create the interceptor with your custom authorization manager
        AuthorizationManagerBeforeMethodInterceptor interceptor = 
            new AuthorizationManagerBeforeMethodInterceptor(pointcut, customAuthorizationManager);
        
        // Set the order to ensure it runs at the right time
        interceptor.setOrder(AuthorizationInterceptorsOrder.PRE_AUTHORIZE.getOrder());
        
        return interceptor;
    }
	
}
