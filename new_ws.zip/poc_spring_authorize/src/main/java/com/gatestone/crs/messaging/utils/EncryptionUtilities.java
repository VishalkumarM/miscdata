package com.gatestone.crs.messaging.utils;

import java.io.ByteArrayOutputStream;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;

import com.gatestone.crs.messaging.error.GenericApplicationException;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EncryptionUtilities
{
    public static final Provider provider = new BouncyCastleProvider();
    
    public static final String DEFAULT_PRIVATE = "MIIG/QIBADANBgkqhkiG9w0BAQEFAASCBucwggbjAgEAAoIBgQC2r5QycCrNF9AGQUQW6FJtuL8JTTrkThrpCKK0l29L9vEm89ocnSWGXjQzpy2aoKj54Tc+UZD7g8qWpmcTF0VAuVpugpI2ZGqYfagI9DCmaIBIYICJ3Z4xexjdDzTIdWTTv3JTENRoTF/sqGSq4gjYYNEdtt/037r3NSSvlJmpHzqSAl0Xu/uh9A2Ae8cbouRKMevh7hJDtGYe08j+jI9mLX2X/h/HPK60CutMVp4PG2lg1V7QHQK0knyluLS58nsTnBO54Ovu1teMVgrLdPzwJPUK1mtF1VCejS/tkcCgeIZIydSrXsCyAiFA3cg1C+SwXUIJsOHFq+YqcgYZ8i9wm+NqY2Dk9wj5GxQ0O5x3lFdUiKJhcc2DtMIGpAfTWUPsjDHg7dDBiI0kaG+lENr8yENg2lYf9L176Uj8Y2OSNfMXMgsBBYpXlCNI+9c73/pL8cMG4JzwUJG3UU+thGN2yCFDrrEeY5bfk89Rirvg0BqOPoi8HRmWHL0THFwWs5cCAwEAAQKCAYAAl6Qm37c70AJ0Kr0CSAGQaoNwD8iLmfc7XzRL2pvZRrU0d6Dy682F2INZ0YZz1GaH3OOVd6U9M4myIFsANFico50384Nu2rd/xBSJ5uTLfVZBJdL033uWVHxZpyV4Ku1HRH0l6M2PgwPinA8rgK0fqnyzGHc0b49HIux6B0TSSBAkDg7oN0tTFJwAmSYloEsWNIA7zM5RWuHj4rLppGIIpkgceI340ukMG2b06ej8So32auqySQ3LsRfnX6hyW+dp2lzdQPHsOl6/VmNLDdDGFEF4s/WD2xF4KZvkf6djdr5ptEW/WICrPSUAfNsa3hY9P2kac54iDnM0BaEBgf8mhyFj35nmKPe4eHBozdcH18EAdtjBgBiKCAO3KcTHcb0+JNKJdOac6bKbPvYOWKxoN1tFakzbIXjmm2lOmK+C3TNRv9c3LlpWKgbUnHlrcrPwdeRPwmQvmMm1D5Z7xvWJ5n6jJZYXVj2kRu8IexJ7GVM591Kfh/VLGANF03gKBX0CgcEA6NRb/w6ZmPl8OKntdqF4ctrMr5kHeyMfKDU8OZ6JKqtCKatjEcvepBSeV+HKK+D/UyovUd4imZ5y/RE0eCRhd4CX/SrVrpWbdHDQ+pVzu3txNimTby6YrzG0N/vHbeHGs/AILoyuWUsWOvYHyZ17CtgehKTUBPEJJjo8hzRErjMT3My+OkBYfdd1QDxUdWHEBdmAPTRcJ1xqix13855Ja1Wtn1WVScfeZ5CsqrC+EJL6esvv3BY8Gujbh1iobVDDAoHBAMjdvjci0wfO7g0IuDTFRMRU8GMncURFYMUoTLi2g9EzNlSBSbPGqvML8Ps57ExmZneFxmKgDBA+h7Dks1mEuqsQjRQVR28pjYR5A69o6xMYe9d55iuqKTtzGG+BKw60tC0WOQWUQCWbaIX6LHTGMbJfmC8/a+bREZqUC9iUyeYqaAXMWDHoHCUyJSJINSpV/XSt60O0wH9/iFVoy9d7tQTH8MLMeUmqziHI744HNtSwYpYZV2UMf3ObC01uVIBknQKBwE/o2q4+d48eSXk1MTAfGTTqTYgTEJM9qarmIoZwGAnR/4JHtVfdTcuo2/OzpezLazZC6zzA7cUlsbeTmRuG+QDH3OJiOjaSWGltcvweITt+kYuSV2y4ZGT0vTLdskPPUqBdSKGZXRl+gOG5oVCcQSemp0rFO5N6mrZJFI8e7FeRZkbI6p0ZioWeVjq2uhITfPC5Bp97AgnsWRDoC0xMzkwNeuqNuBA7jeSjre9je8g6ecd9iRRTeUuPEhFw51WlewKBwGYjg27r8V0eFyRfk7OZv/8Jpfb1fn4VvUBj3qdqf5roLK9J0t1sn07Zep9087hhtab/SkKqWZgFA+CqWpyhhn4n+2UD8QAQpBqBoqMWebqLD6YhIS6A51iIjRteFjPzJU9r5nD00q2M2diOvv5eLbUjMPKNkGOdWhM9RszJ0+SLGbwhDZPLEEzFs+Y7y3UMpsYnDeOuzNfIVN4BXO3kxMZ6mO2lJeOUzB6X22BgQLxkOK1Uk4EZmtGBPH0SJjvnbQKBwQCvk4OMy5hv/D8B7GWCzxOYb92mcI6kk7Yj/1t6DFUlKTwLnnIXOBd9+2M3zbQqgSk33Bi98alBZ3ajsTST//yYsy9wO/MjNzFhAs2dwCfLCG4J6DfYKDj1DfzPXLlF7JannV88MR54T+DjfYAaHsH9qI9cplF0eZMfJgdLGDR/vEysvL9xUc3Kd8h2ciFICT/zEs7/0uzZqRsmovJg3tF0uWd77mY99CvdiS4aMmkk26kn3Km+GbGul5rNCSmyY+E=";
    public static final String DEFAULT_PUBLIC = "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAtq+UMnAqzRfQBkFEFuhSbbi/CU065E4a6QiitJdvS/bxJvPaHJ0lhl40M6ctmqCo+eE3PlGQ+4PKlqZnExdFQLlaboKSNmRqmH2oCPQwpmiASGCAid2eMXsY3Q80yHVk079yUxDUaExf7KhkquII2GDRHbbf9N+69zUkr5SZqR86kgJdF7v7ofQNgHvHG6LkSjHr4e4SQ7RmHtPI/oyPZi19l/4fxzyutArrTFaeDxtpYNVe0B0CtJJ8pbi0ufJ7E5wTueDr7tbXjFYKy3T88CT1CtZrRdVQno0v7ZHAoHiGSMnUq17AsgIhQN3INQvksF1CCbDhxavmKnIGGfIvcJvjamNg5PcI+RsUNDucd5RXVIiiYXHNg7TCBqQH01lD7Iwx4O3QwYiNJGhvpRDa/MhDYNpWH/S9e+lI/GNjkjXzFzILAQWKV5QjSPvXO9/6S/HDBuCc8FCRt1FPrYRjdsghQ66xHmOW35PPUYq74NAajj6IvB0Zlhy9ExxcFrOXAgMBAAE=";
    public static final String ALGO_MD5 = "MD5";
    public static final String ALGO_SHA512 = "SHA-512";
    public static final String ALGO_SHA256 = "SHA-256";
    public static final String CIPHER = "RSA/None/PKCS1Padding";
    public static final String KEY_RSA = "RSA";
    public static final String PROVIDER_CODE = "BC";
    public static final String SIGNATURE_ALGO = "SHA256withRSA";
    
    public static final String BEGIN_RSA_PUB = "-----BEGIN RSA PUBLIC KEY-----";
    public static final String END_RSA_PUB = "-----END RSA PUBLIC KEY-----";
    public static final String BEGIN_PUB = "-----BEGIN PUBLIC KEY-----";
    public static final String END_PUB = "-----END PUBLIC KEY-----";
    
    
    public static String doMD5(String pData) throws Exception {
    	byte[] lHash =  doHash(ALGO_MD5, pData);
		return hex(lHash);
    }
    
    public static String doSha256(byte[] pBytes) throws Exception {
    	byte[] lHash =  doHash(ALGO_SHA256, pBytes);
    	return hex(lHash);
    }
    
    public static byte[] doHash(String pAlgorithm, String pData) throws Exception {
		byte[] lByteData = pData.getBytes();
		return doHash(pAlgorithm, lByteData);
	}
    
    public static byte[] doHash(String pAlgorithm, byte[] pData) throws Exception {
		MessageDigest lMessageDigest = MessageDigest.getInstance(pAlgorithm);
		lMessageDigest.reset();
		lMessageDigest.update(pData);
		return lMessageDigest.digest();
	}
    
    private static byte[] deCipher(Cipher pCipher,byte[] pBytes,int pKeyLength) throws Exception {
        byte[] lTempArray = new byte[0];
        ByteArrayOutputStream lBtArrayOutputStream = new ByteArrayOutputStream();
        int lLength = (pKeyLength / 8);
        byte[] lBuffer = new byte[(pBytes.length > lLength ? lLength : pBytes.length)];
        for (int i = 0; i < pBytes.length; i++) {
            if ((i > 0) && (i % lLength == 0)) {
                lTempArray = pCipher.doFinal(lBuffer);
                lBtArrayOutputStream.write(lTempArray);
                int lNewLength = lLength;
                if (i + lLength > pBytes.length) {
                    lNewLength = pBytes.length - i;
                }
                lBuffer = new byte[lNewLength];
            }
            lBuffer[i % lLength] = pBytes[i];
        }
        lTempArray = pCipher.doFinal(lBuffer);
        lBtArrayOutputStream.write(lTempArray);
        lBtArrayOutputStream.close();
        return lBtArrayOutputStream.toByteArray();
    }
    
    public static byte[] decrypt(byte[] pData,PublicKey pPublicKey) throws Exception {
        Cipher lDeCipher = Cipher.getInstance(CIPHER ,provider);
        lDeCipher.init(Cipher.DECRYPT_MODE, pPublicKey);
        int lKeyLength = ((RSAPublicKey)pPublicKey).getModulus().bitLength();
        return deCipher(lDeCipher, pData, lKeyLength);
    }
    
    public static byte[] decrypt(byte[] pData,PrivateKey pPrivateKey) throws Exception {
        Cipher lDeCipher = Cipher.getInstance(CIPHER ,provider);
        lDeCipher.init(Cipher.DECRYPT_MODE, pPrivateKey);
        int lKeyLength = ((RSAPrivateKey)pPrivateKey).getModulus().bitLength();
        return deCipher(lDeCipher, pData, lKeyLength);
    }
    
    public static byte[] decrypt(String pDataBase64,PublicKey pPublicKey) throws Exception {
        return decrypt(Base64.decode(pDataBase64), pPublicKey);
    }
    
    public static byte[] decrypt(String pDataBase64,PrivateKey pPrivateKey) throws Exception {
        return decrypt(Base64.decode(pDataBase64), pPrivateKey);
    }
    
    private static byte[] enCipher(Cipher pCipher,byte[] pBytes,int pKeyLength) throws Exception {
        byte[] lTempArray = new byte[0];
        ByteArrayOutputStream lBtArrayOutputStream = new ByteArrayOutputStream();
        int lLength = (pKeyLength / 8) - 11;
        byte[] lBuffer = new byte[(pBytes.length > lLength ? lLength : pBytes.length)];
        for (int i = 0; i < pBytes.length; i++) {
            if ((i > 0) && (i % lLength == 0)) {
                lTempArray = pCipher.doFinal(lBuffer);
                lBtArrayOutputStream.write(lTempArray);
                int lNewlength = lLength;
                if (i + lLength > pBytes.length) {
                    lNewlength = pBytes.length - i;
                }
                lBuffer = new byte[lNewlength];
            }
            lBuffer[i % lLength] = pBytes[i];
        }
        lTempArray = pCipher.doFinal(lBuffer);
        lBtArrayOutputStream.write(lTempArray);
        lBtArrayOutputStream.close();
        return lBtArrayOutputStream.toByteArray();
    }
    
    public static byte[] encrypt(byte[] pData,PublicKey pPublicKey) throws Exception {
        Cipher lEnCipher = Cipher.getInstance(CIPHER,provider);
        lEnCipher.init(Cipher.ENCRYPT_MODE, pPublicKey);
        int lKeyLength = ((RSAPublicKey)pPublicKey).getModulus().bitLength();
        return enCipher(lEnCipher, pData, lKeyLength);
    }
    
    public static byte[] encrypt(byte[] pData,PrivateKey pPrivateKey) throws Exception {
        Cipher lEnCipher = Cipher.getInstance(CIPHER,provider);
        lEnCipher.init(Cipher.ENCRYPT_MODE, pPrivateKey);
        int lKeyLength = ((RSAPrivateKey)pPrivateKey).getModulus().bitLength();
        return enCipher(lEnCipher, pData, lKeyLength);
    }
    
    public static byte[] encrypt(String pDataBase64,PublicKey pPublicKey) throws Exception {
        return encrypt(Base64.decode(pDataBase64), pPublicKey);
    }
    
    public static byte[] encrypt(String pDataBase64,PrivateKey pPrivateKey) throws Exception {
        return encrypt(Base64.decode(pDataBase64), pPrivateKey);
    }
    
    public static byte[] base64Decode(String pString) {
        return Base64.decode(pString);
    }
    
    public static String base64Encode(byte[] pData) {
        return new String(Base64.encode(pData));
    }
    
    public static final String BEGIN_RSA_PRV = "-----BEGIN RSA PRIVATE KEY-----";
    public static final String END_RSA_PRV = "-----END RSA PRIVATE KEY-----";
    public static final String BEGIN_PRV = "-----BEGIN PRIVATE KEY-----";
    public static final String END_PRV = "-----END PRIVATE KEY-----";
    
    public static PrivateKey parsePrivateKey(String pKeyData) throws Exception {
        String lTemp = pKeyData; 
        if(pKeyData.indexOf(BEGIN_RSA_PRV) >= 0) {
            lTemp = lTemp.replace(BEGIN_RSA_PRV, "");
            lTemp = lTemp.replace(END_RSA_PRV, "");
        }
        if(pKeyData.indexOf(BEGIN_PRV) >= 0) {
            lTemp = lTemp.replace(BEGIN_PRV, "");
            lTemp = lTemp.replace(END_PRV, "");
        }
        // Base64 decode the data
        byte [] lDecoded = Base64.decode(lTemp);
        // PKCS8 decode the encoded RSA private key
        PKCS8EncodedKeySpec lKeySpecs = new PKCS8EncodedKeySpec(lDecoded);
        KeyFactory lKeyFactory = KeyFactory.getInstance(KEY_RSA,provider);
        PrivateKey lPrivateKey = lKeyFactory.generatePrivate(lKeySpecs);
        return lPrivateKey;
    }
    
    public static PublicKey parsePublicKey(String pKeyData) throws Exception {
        String lTemp = pKeyData; 
        if(pKeyData.indexOf(BEGIN_RSA_PUB) >= 0) {
            lTemp = lTemp.replace(BEGIN_RSA_PUB, "");
            lTemp = lTemp.replace(END_RSA_PUB, "");
        }
        if(pKeyData.indexOf(BEGIN_PUB) >= 0) {
            lTemp = lTemp.replace(BEGIN_PUB, "");
            lTemp = lTemp.replace(END_RSA_PUB, "");
        }
        // Base64 decode the data
        byte [] lDecoded = Base64.decode(lTemp);
        // X509EncodedKeySpec decode the encoded RSA Public key
        X509EncodedKeySpec lKeySpecs = new X509EncodedKeySpec(lDecoded);
        KeyFactory lKeyFactory = KeyFactory.getInstance(KEY_RSA,provider);
        PublicKey lPublicKey = lKeyFactory.generatePublic(lKeySpecs);
        return lPublicKey;
    }

    public static String[] keyGenerator(int pSize) throws NoSuchAlgorithmException, NoSuchProviderException {
        Security.addProvider(new BouncyCastleProvider());
        KeyPairGenerator lGenerator = KeyPairGenerator.getInstance(KEY_RSA, PROVIDER_CODE);
        SecureRandom lRandom = new SecureRandom();
        lGenerator.initialize(pSize, lRandom);
        KeyPair lKeyPair = lGenerator.generateKeyPair();
        Key lPublicKey = lKeyPair.getPublic();
        Key lPrivateKey = lKeyPair.getPrivate();
        String lPublicKeyStr = new String(Base64.encode(lPublicKey.getEncoded()));
        String lPrivateKeyStr = new String(Base64.encode(lPrivateKey.getEncoded()));
        RSAPublicKey pub = (RSAPublicKey) lPublicKey;
        return new String[] {lPrivateKeyStr, lPublicKeyStr};
    }
    
    public static byte[] hexStringToByteArray(String pInput) {
        byte[] lReturn = new byte[pInput.length() / 2];
        for (int lPtr = 0; lPtr < lReturn.length; lPtr++) 
        {
          int lIndex = lPtr * 2;
          int lValue = Integer.parseInt(pInput.substring(lIndex, lIndex + 2), 16);
          lReturn[lPtr] = (byte) lValue;
        }
        return lReturn;
    }
    
    public static boolean verifySignature(byte[] pData, PublicKey pPublcKey, byte[] pSignature) throws Exception {
        Signature lSignature = Signature.getInstance(SIGNATURE_ALGO);
        lSignature.initVerify(pPublcKey);
        lSignature.update(pData);
        return (lSignature.verify(pSignature));
    }
    
    public static boolean verifySignature(byte[] pData, String pPublicKey, byte[] pSignature) throws Exception {
   	 	PublicKey lPublicKey = parsePublicKey(pPublicKey);
   	 	return verifySignature(pData, lPublicKey, pSignature);
    }
    
    public static boolean verifySignature(String pData, String pPublicKey, String pSignature) throws Exception {
        PublicKey lPublicKey = parsePublicKey(pPublicKey);
        return verifySignature(pData.getBytes(), lPublicKey, pSignature.getBytes());
    }
    
    public static boolean verifySignature(String pData, String pPublicKey, byte[] pSignature) throws Exception {
        PublicKey lPublicKey = parsePublicKey(pPublicKey);
        return verifySignature(pData.getBytes(), lPublicKey, pSignature);
    }
    
    public static String sign(byte[] pData, PrivateKey pPrivateKey,String pAlgorithm) throws Exception {
		Signature lSignature = Signature.getInstance(pAlgorithm); 
		lSignature.initSign(pPrivateKey);
		lSignature.update(pData);
		byte[] lSignBytes = lSignature.sign();
		return base64Encode(lSignBytes);//Hex.encodeHexString(lSignBytes);
    }
    
    public static String signRSAES256(byte[] pData, PrivateKey pPrivateKey) throws Exception {
    	return sign(pData, pPrivateKey, "SHA256withRSA");
    }
    
    public static String signRSAES256(String pData, String pPrivateKey) throws Exception {
    	PrivateKey lPriveteKey = parsePrivateKey(pPrivateKey);
		return signRSAES256(pData.getBytes(), lPriveteKey);
    }
    
    public static String hex(byte[] bytes) {
        return Hex.encodeHexString(bytes);
    }
    
    public static byte[] hex(String str) {
        try {
            return Hex.decodeHex(str.toCharArray());
        }
        catch (DecoderException e) {
            throw new IllegalStateException(e);
        }
    }
    
    
    public static String getHeader(HttpServletRequest pRequest, String pKey) {
        return (pRequest == null)? null:pRequest.getHeader(pKey);
    }
    
    public static String generateRsaEncryptedSha64(String publicKeyStr, String pMessage) throws Exception {
    	String lSha256 = EncryptionUtilities.doSha256(pMessage.getBytes());
    	byte[] lEncrypted = EncryptionUtilities.encrypt(lSha256.getBytes(), EncryptionUtilities.parsePublicKey(publicKeyStr));
    	return EncryptionUtilities.base64Encode(lEncrypted);
    }
    
    public static void verifyRsaEncryptedSha64(String publicKeyStr, String pMessage, String pMacBase64) throws Exception {
    	//create SHA256 Hash
    	String lSha256 = EncryptionUtilities.doSha256(pMessage.getBytes());
    	//Decrypt the message with private key
    	byte[] lInpHash = EncryptionUtilities.decrypt(pMacBase64, EncryptionUtilities.parsePublicKey(publicKeyStr));
    	//match the hash
    	boolean lVerified = lSha256.equalsIgnoreCase(new String(lInpHash));
        if(!lVerified) {
        	throw new GenericApplicationException("Message integrity verify failed");
        }
    }
    
    public static void verifySignature64(String publicKeyStr, String pContent, String pSignature) throws Exception {
    	byte [] lDecoded = Base64.decode(pSignature);
        boolean lVerified = EncryptionUtilities.verifySignature(pContent, publicKeyStr, lDecoded);
        if(!lVerified) {
        	throw new GenericApplicationException("Message integrity verify failed");
        }
    }
    
    public static void verifySignature(String publicKeyStr, byte[] pContent, String pSignature) throws Exception {
    	byte [] lDecoded = Base64.decode(pSignature);
        boolean lVerified = EncryptionUtilities.verifySignature(pContent, publicKeyStr, lDecoded);
        if(!lVerified) {
        	throw new GenericApplicationException("Message integrity verify failed");
        }
    }
    
    public static String[] getNewKeyPair() throws Exception {
        return EncryptionUtilities.keyGenerator(2048);
    }
    
    public static String encrypt(byte[] pString) {
        if (pString != null) {
            try {
				return EncryptionUtilities.base64Encode(EncryptionUtilities.encrypt(pString,
						EncryptionUtilities.parsePrivateKey(EncryptionUtilities.DEFAULT_PRIVATE)));
            } catch (Exception lException) {
                log.error("Error while enrypting string " + pString, lException);
            }
        }
        return null;
    }
    
    public static String encrypt(String pString) {
        if (pString != null) {
            try {
				return EncryptionUtilities.base64Encode(EncryptionUtilities.encrypt(pString.getBytes(),
						EncryptionUtilities.parsePrivateKey(EncryptionUtilities.DEFAULT_PRIVATE)));
            } catch (Exception lException) {
                log.error("Error while enrypting string " + pString, lException);
            }
        }
        return null;
    }
    
    public static String sign(byte[] pString) {
    	if (pString != null) {
            try {
				return EncryptionUtilities.signRSAES256(pString,
						EncryptionUtilities.parsePrivateKey(EncryptionUtilities.DEFAULT_PRIVATE));
            } catch (Exception lException) {
                log.error("Error while enrypting string " + pString, lException);
            }
        }
    	return null;
    }
    
    public static String sign(String pString) {
    	if (pString != null) {
            try {
                return EncryptionUtilities.signRSAES256(pString, EncryptionUtilities.DEFAULT_PRIVATE);
            } catch (Exception lException) {
                log.error("Error while enrypting string " + pString, lException);
            }
        }
    	return null;
    }
    
    public static void main(String...args) {
    	int strength = 3072;
    	
    	try {
			String[] keyparts = keyGenerator(strength);
			System.out.println("PRV :: "+keyparts[0]);
			System.out.println("PUB :: "+keyparts[1]);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

}
