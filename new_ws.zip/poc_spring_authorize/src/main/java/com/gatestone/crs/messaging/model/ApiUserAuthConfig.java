package com.gatestone.crs.messaging.model;

import com.gatestone.crs.messaging.model.enums.AuthServiceType;
import com.gatestone.crs.messaging.model.enums.ServiceStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
public class ApiUserAuthConfig {
	
	private AuthServiceType type;
	private ServiceStatus status;
	private String ein;
	private String email;
}
