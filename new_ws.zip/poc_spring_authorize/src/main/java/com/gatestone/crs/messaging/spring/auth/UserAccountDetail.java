package com.gatestone.crs.messaging.spring.auth;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.gatestone.crs.messaging.model.ApiUserAuthConfig;

public class UserAccountDetail extends ApiUserAuthConfig implements UserDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2758412955099135368L;
	
	private Collection<? extends GrantedAuthority> actions;
	
	public UserAccountDetail() {
		
	}
	
	  // Constructor to populate from another ApiUserAuthConfig instance
    public UserAccountDetail(ApiUserAuthConfig config) {
    	this.setType(config.getType());
    	this.setStatus(config.getStatus());
    	this.setEin(config.getEin());
        this.setEmail(config.getEmail());
    }

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		if(actions == null)
			return Collections.emptyList();
		return actions;
	}

	@Override
	public String getPassword() {
		return "-";
	}

	@Override
	public String getUsername() {
		return super.getEin();
	}
	
	public void setActions(Collection<? extends GrantedAuthority> actions) {
		this.actions = actions;
	}

}
