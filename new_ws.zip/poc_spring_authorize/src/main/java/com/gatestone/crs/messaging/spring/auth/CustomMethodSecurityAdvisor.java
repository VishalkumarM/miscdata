package com.gatestone.crs.messaging.spring.auth;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public class CustomMethodSecurityAdvisor extends DefaultPointcutAdvisor {

    public CustomMethodSecurityAdvisor(AuthorizationManager<MethodInvocation> authorizationManager) {
        super(new MethodSecurityInterceptor(authorizationManager));
    }

    private static class MethodSecurityInterceptor implements MethodInterceptor {
        private final AuthorizationManager<MethodInvocation> authorizationManager;

        public MethodSecurityInterceptor(AuthorizationManager<MethodInvocation> authorizationManager) {
            this.authorizationManager = authorizationManager;
        }

        @Override
        public Object invoke(org.aopalliance.intercept.MethodInvocation invocation) throws Throwable {
            // Create a method invocation context and apply authorization
            AuthorizationDecision decision = authorizationManager.check(
                    () -> (Authentication) SecurityContextHolder.getContext().getAuthentication(), 
                    invocation
            );
            
            if (!decision.isGranted()) {
                throw new SecurityException("Access Denied");
            }
            return invocation.proceed();
        }
    }
}

