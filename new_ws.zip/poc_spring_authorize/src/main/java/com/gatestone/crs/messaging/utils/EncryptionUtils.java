package com.gatestone.crs.messaging.utils;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import com.gatestone.crs.messaging.utils.AesGcmCryptor.CryptoException;

class EncryptionUtils {

	protected static byte[] keyArray = { 0x42, 0x76, 0x5a, 0x57, 0x38, 0x4a, 0x59, 0x4f, 0x72, 0x51, 0x57, 0x30, 0x68,
			0x42, 0x6b };

	public static IvParameterSpec generateIv() {
		byte[] iv = new byte[16];
		new SecureRandom().nextBytes(iv);
		return new IvParameterSpec(iv);
	}

	public static String encrypt(String algorithm, String input, SecretKey key, IvParameterSpec iv)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

		Cipher cipher = Cipher.getInstance(algorithm);
		cipher.init(Cipher.ENCRYPT_MODE, key, iv);
		byte[] cipherText = cipher.doFinal(input.getBytes());
		return Base64.getEncoder().encodeToString(cipherText);
	}

	public static String decrypt(String algorithm, String cipherText, SecretKey key, IvParameterSpec iv)
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

		Cipher cipher = Cipher.getInstance(algorithm);
		cipher.init(Cipher.DECRYPT_MODE, key, iv);
		byte[] plainText = cipher.doFinal(Base64.getDecoder().decode(cipherText));
		return new String(plainText);
	}

	public static void main(String[] args) {

		if (args.length < 1) {
			System.err.println("ERROR :: mandatory argument data to be encrypted missing");
			return;
		}
		String inpValue = args[0];
		AesGcmCryptor enc = new AesGcmCryptor();
		try {
			String encValue = enc.encryptString(new String(keyArray).toCharArray(), inpValue);
			encValue = "[AES] " + encValue;
			System.out.println("*****************************************************************");
			System.out.println(encValue);
			System.out.println("*****************************************************************");
			
		} catch (CryptoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
