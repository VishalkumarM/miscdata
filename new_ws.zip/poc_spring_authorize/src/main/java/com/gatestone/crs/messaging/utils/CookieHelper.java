package com.gatestone.crs.messaging.utils;

import java.security.PrivateKey;
import java.security.PublicKey;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CookieHelper {

	public static final String COOKIE_NAME = "sess_id";

	public String extractSecureCookie(HttpServletRequest request, String cookieName, boolean secure, boolean httpOnly) {
		try {
			// Get the cookie
			Cookie[] cookies = request.getCookies();
			if (cookies == null) {
				return null;
			}

			// Find our specific cookie
			String encryptedValue = null;
			Cookie tmpCookie = null;
			for (Cookie cookie : cookies) {
				if (cookieName.equalsIgnoreCase(cookie.getName())) {
					tmpCookie = cookie;
					encryptedValue = cookie.getValue();
					break;
				}
			}

			if (encryptedValue == null) {
				return null;
			}

			if (secure && !tmpCookie.getSecure()) {
				return null;
			}

			if (httpOnly && !tmpCookie.isHttpOnly()) {
				return null;
			}
			byte[] cookieBytes =  EncryptionUtilities.hex(encryptedValue); 

			PublicKey pubKey = EncryptionUtilities.parsePublicKey(EncryptionUtilities.DEFAULT_PUBLIC);

			// Decrypt the cookie value
			byte[] decryptedValue = EncryptionUtilities.decrypt(cookieBytes, pubKey);

			return new String(decryptedValue);
		} catch (Exception e) {
			// Handle or log the exception appropriately
			throw new RuntimeException("Failed to process user cookie", e);
		}
	}
	
	public void addEncryptedCookie(String data, HttpServletResponse response, String cookieName, boolean secure, boolean httpOnly) {
		
		try {
			PrivateKey privKey = EncryptionUtilities.parsePrivateKey(EncryptionUtilities.DEFAULT_PRIVATE);
			byte[] encryptedData = EncryptionUtilities.encrypt(data.getBytes(), privKey);
			String cookieBase64 =  EncryptionUtilities.hex(encryptedData);
			Cookie sessionCookie = new Cookie(cookieName, cookieBase64);
			sessionCookie.setPath("/");
			sessionCookie.setHttpOnly(httpOnly);
			sessionCookie.setSecure(secure);
			response.addCookie(sessionCookie);
		} catch (Exception e) {
			throw new RuntimeException("Failed to process user cookie", e);
		}
        
	}

	private boolean validateHeaders(HttpServletRequest request) {
		// Check for required security headers
		String xssProtection = request.getHeader("X-XSS-Protection");
		String contentSecurityPolicy = request.getHeader("Content-Security-Policy");
		return xssProtection != null && contentSecurityPolicy != null;
	}

	private boolean isValidRequest(HttpServletRequest request) {
		// Validate request origin, headers, etc.
		String expectedOrigin = System.getenv("ALLOWED_ORIGIN");
		String requestOrigin = request.getHeader("Origin");
		return expectedOrigin.equals(requestOrigin);
	}

}