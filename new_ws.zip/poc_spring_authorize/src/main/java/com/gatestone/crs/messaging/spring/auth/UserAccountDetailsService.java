package com.gatestone.crs.messaging.spring.auth;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.gatestone.crs.messaging.error.MessagingAccessDeniedException;
import com.gatestone.crs.messaging.model.enums.AuthServiceType;
import com.gatestone.crs.messaging.model.enums.ServiceStatus;
import com.gatestone.crs.messaging.spring.auth.model.Action;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class UserAccountDetailsService implements UserDetailsService {
	
	private List<UserAccountDetail> users;
	private Map<String, UserAccountDetail> usersByEin;
	
	@PostConstruct
	public void init() {
		users = new ArrayList<UserAccountDetail>();
		users.add(createUser("123456", "viewer@user.c", new String[]{"VW.PROFILE"}));
		users.add(createUser("654321", "editor@user.c", new String[]{"MD.PROFILE"}));
		usersByEin = users.stream().filter(user -> user.getEin() != null) // filter out users with null EIN
				.collect(Collectors.toMap(user -> user.getEin().trim().toUpperCase(),	//UserAccountDetail::getEin, 
						Function.identity(), (existing, replacement) -> replacement, // keep latest occurrence in case of duplicates
						ConcurrentHashMap::new));
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		if(StringUtils.isBlank(username)) {
			throw new MessagingAccessDeniedException("Invalid Authorization");
		}
		UserAccountDetail user = usersByEin.get(username.trim().toUpperCase());
		if(user == null) {
			throw new MessagingAccessDeniedException("User not found :: " + username);
		}
		if(user.getStatus() != ServiceStatus.ACTIVE) {
			throw new MessagingAccessDeniedException("User not active :: " + username);
		}
		UserAccountDetail userAccountDetails = new UserAccountDetail(user);
		userAccountDetails.setActions((Collection<? extends GrantedAuthority>) Arrays.asList(user.getAuthorities()));
		return userAccountDetails;
	}
	
	private UserAccountDetail createUser(String ein, String email, String[] roles) {
		UserAccountDetail details = new UserAccountDetail();
		details.setType(AuthServiceType.OAUTH);
		details.setStatus(ServiceStatus.ACTIVE);
		details.setEin(ein);
		details.setEmail(email);
		List<Action> actions = new ArrayList<Action>();
		details.setActions(actions);
		if(roles != null) {
			for(String role : roles) {
				actions.add(getAction(role));
			}
		}
		return details;
	}
	
	private Action getAction(String role) {
		Action action = new Action();
		action.setAction(role);
		return action;
	}

}
