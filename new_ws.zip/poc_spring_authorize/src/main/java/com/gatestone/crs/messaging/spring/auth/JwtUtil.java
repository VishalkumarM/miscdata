package com.gatestone.crs.messaging.spring.auth;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;

import org.springframework.stereotype.Service;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import com.nimbusds.jwt.SignedJWT;

import jakarta.annotation.PostConstruct;

@Service
public class JwtUtil {
	
	private static final String CLEINT_ID = "azp";
	private Cache<Long, PublicKey> authPublicKeys;
	
	@PostConstruct
	private void init() {
		authPublicKeys = Caffeine.newBuilder().expireAfterWrite(Duration.ofMinutes(10)).build();
	}
	
	public JwtParserBuilder newJwtParser(String token) throws Exception {
		return new JwtParserBuilder(token);
	}
	
	public PublicKey getKey(Long id) {
		return authPublicKeys.getIfPresent(id);
	}
	
	/**
	 * 
	 * @param id
	 * @param key
	 */
	public void putKey(Long id, PublicKey key) {
		authPublicKeys.put(id, key);
	}
	
	/**
	 * 
	 * @param id
	 * @param keyStr
	 * @throws Exception
	 */
	public void parseAndAddRsaKey(Long id, String keyStr) throws Exception {
		putKey(id, rsaPublicKeyParser(keyStr));
	}
	
	public PublicKey rsaPublicKeyParser(String jwtPublicKey)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		byte[] keyBytes = Base64.getDecoder().decode(jwtPublicKey);
		X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(keyBytes);
		return keyFactory.generatePublic(x509EncodedKeySpec);
	}

	public PrivateKey rsaPrivateKeyParser(String jwtPrivateKey)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		byte[] keyBytes = Base64.getDecoder().decode(jwtPrivateKey);
		PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(keyBytes);
		return keyFactory.generatePrivate(pkcs8EncodedKeySpec);
	}
	
	public static class JwtParserBuilder {
		
		private String token;
		private JWTClaimsSet claimsSet;
		private JWT jwt;
		
		public JwtParserBuilder(String token) throws Exception {
			this.token = token;
			processToken();
		}
		
		private void processToken() throws Exception {
			jwt = JWTParser.parse(token);
			claimsSet = jwt.getJWTClaimsSet();
			//System.out.println(claimsSet.getStringClaim("azp"));
		}
		
		public boolean isTokenExpired() {
	        try {
	            Date expirationTime = claimsSet.getExpirationTime();
	            return expirationTime == null || new Date().after(expirationTime);
	        } catch (Exception e) {
	            return true;
	        }
	    }
		
		public boolean isSignatureValid(PublicKey pubKey) {
	        try {
	            SignedJWT signedJWT = SignedJWT.parse(token);
	            JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) pubKey);
	            return signedJWT.verify(verifier);
	        } catch (Exception e) {
	            return false;
	        }
	    }
		
		public String extractUsername() throws Exception {
			return claimsSet.getStringClaim(CLEINT_ID);
	    }
		
//		private Boolean isTokenExpired(String token) {
//	        return extractExpiration(token).before(new Date());
//	    }
		
//		public String extractUsername(String token) throws Exception {
//			if(StringUtils.isBlank(claimsSet.getSubject())) {
//				return claimsSet.getStringClaim(CLEINT_ID);
//			}
//			return claimsSet.getSubject();
//	        
//	    }
	}
}
