package com.gatestone.crs.messaging.model.enums;

public interface IGenericEnum<T> {

	public T getCode();
	public String getDescription();
	public IGenericEnum<T> get(T code);
}
