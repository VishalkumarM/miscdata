package com.gatestone.crs.messaging.utils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

public class ApplicationUtils {
	
	private ApplicationUtils() {
		
	}
	
	public static String generateUuid() {
		UUID uuid = UUID.randomUUID();
		return uuid.toString();
	}
	
	public static final boolean hasValue(Object value) {
		if(value == null)
			return false;
		Class<? extends Object> clazz = value.getClass();
		if(List.class.isAssignableFrom(clazz)) {
			return !((List<?>) value).isEmpty();
		} else if(CharSequence.class.isAssignableFrom(clazz)) {
			return value.toString().trim().length() > 0;
		} else if(value.getClass().isArray()) {
			return ((Object[])value).length > 0;
		}
		return true;
	}
	
	public static boolean isNotBlank(final String value) {
		return hasValue(value);
	}
	
	public static boolean isBlank(final String value) {
		return !hasValue(value);
	}
	
	public static String getDateString(Date date, String format) {
		SimpleDateFormat dateString = new SimpleDateFormat(format);
		return dateString.format(date);
	}
	
	public static Timestamp getTsimestamp(String dateString, String format) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		dateFormatter.setLenient(false);
		java.util.Date date;
		try {
			date = dateFormatter.parse(dateString);
			 return new Timestamp(date.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static String formatDate(Date date, String format) {
		LocalDateTime localDateTime = date.toInstant()
                .atZone(ZoneId.systemDefault())  // Using the system default timezone
                .toLocalDateTime();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(format);
        return localDateTime.format(dateTimeFormatter);
	}
	
	public static Date addDays(Date date, int days) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DATE, days);
		return calendar.getTime();
	}
	
	public static <T> boolean validateArray(T[] array) {
		return validateArray(array, null);
	}
	
	public static <T> boolean validateArray(T[] array, Integer length) {
		return (array != null && (length == null || array.length > length));
	}
	
	public static Long getLong(String longValue) {
		if(StringUtils.isBlank(longValue) || !NumberUtils.isParsable(longValue))
			return null;
		return Long.valueOf(longValue);
	}
	
	public static Integer getInteger(String longValue) {
		if(StringUtils.isBlank(longValue) || !NumberUtils.isParsable(longValue))
			return null;
		return Integer.valueOf(longValue);
	}
	
	public static Integer getInteger(Object longValue) {
		if(longValue == null)
			return null;
		String longValueStr = longValue.toString();
		if(StringUtils.isBlank(longValueStr) || !NumberUtils.isParsable(longValueStr))
			return null;
		return Integer.valueOf(longValueStr);
	}
	
	public static BigDecimal getBigDecimal(String objValue, int decimalPrecision) {
		
		if(StringUtils.isBlank(objValue) || !NumberUtils.isParsable(objValue))
			return null;
		return new BigDecimal(objValue).setScale(decimalPrecision, RoundingMode.HALF_UP);
	}
	
	public static String getString(String stringValue) {
		if(StringUtils.isBlank(stringValue))
			return null;
		return String.valueOf(stringValue);
	}
	
	public static String getStringFromArray(int index, String[] array) {
		if(array != null && array.length > index)
			return getString(array[index]);
		return null;
	}
	
	public static Integer getIntegerFromArray(int index, String[] array, int defaultValue) {
		Integer value = null;
		if(array != null && array.length > index)
			 value = getInteger(array[index]);
		if(value == null) {
			value = defaultValue;
		}
		return value;
	}
	
	public static Integer getIntegerFromArray(int index, String[] array) {
		if(array != null && array.length > index)
			return getInteger(array[index]);
		return null;
	}
	
	public static Long getLongFromArray(int index, String[] array) {
		if(array != null && array.length > index)
			return getLong(array[index]);
		return null;
	}
	
	public static BigDecimal getBigDecimalFromArray(int index, int decimalPrecision, String[] array) {
		if(array != null && array.length > index)
			return getBigDecimal(array[index], decimalPrecision);
		return null;
	}
	
	public static  String getMatchingGroup(String patternRegex, String strCurrentLine, int group) {
		Pattern pattern = Pattern.compile(patternRegex);
		Matcher matcher = pattern.matcher(strCurrentLine);
		String key = null;
		if (matcher.find()) {
			key = matcher.group(group);
		}
		return key;
	}
	
	public static String readConfig(String configPath) throws IOException {
		InputStream in = ApplicationUtils.class.getResourceAsStream(configPath);
		if(in == null) {
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			in = loader.getResourceAsStream(configPath);
			if(in == null) {
				in = Files.newInputStream(Paths.get(configPath), StandardOpenOption.READ);
			}
		}
		try(BufferedInputStream bis = new BufferedInputStream(in);
				ByteArrayOutputStream buf = new ByteArrayOutputStream();) {
			for (int result = bis.read(); result != -1; result = bis.read()) {
			    buf.write((byte) result);
			}
			return buf.toString(StandardCharsets.UTF_8.name());
		}
	}
	
	public static InputStream readResource(String configPath) throws IOException {
		InputStream in = ApplicationUtils.class.getResourceAsStream(configPath);
		if(in == null) {
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			in = loader.getResourceAsStream(configPath);
			if(in == null) {
				in = Files.newInputStream(Paths.get(configPath), StandardOpenOption.READ);
			}
		}
		return in;
	}
	
	public static Map<String, String> readConfigAsMap(String configPath, String delimiter) throws IOException {
		Map<String, String> map = new HashMap<>();
		InputStream in = ApplicationUtils.class.getResourceAsStream(configPath);
		if(in == null) {
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			in = loader.getResourceAsStream(configPath);
			if(in == null) {
				in = Files.newInputStream(Paths.get(configPath), StandardOpenOption.READ);
			}
		}
		
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
			String strCurrentLine = null;
			int idx = -1;
			String key = null;
			String value = null;
			while((strCurrentLine = reader.readLine()) != null) {
				idx = strCurrentLine.indexOf(delimiter);
				if(idx > 0) {
					key = strCurrentLine.substring(0, idx);
					if(idx < strCurrentLine.length() - delimiter.length()) {
						value = strCurrentLine.substring(idx + delimiter.length());
					} else {
						value = "";
					}
					map.put(key, value);
				}
			}
		}
		return map;
	}
	
	public static String trim(String input) {
		if(input == null)
			return input;
		return input.replaceAll("^\\s+|\\s+$", "");
	}
	
	public static String concatenate(String delimier, String...paths) {
		StringBuilder responsePath = new StringBuilder();
		for(int ptr = 0; ptr < paths.length - 1; ptr++) {
			String path = paths[ptr];
			if(hasValue(path)) {
				responsePath.append(path);
				if(!path.endsWith(delimier)) {
					responsePath.append(delimier);
				}
			}
		}
		responsePath.append(paths[paths.length - 1]);
		return responsePath.toString();
	}
	
	public static boolean isParsable(final String str) {
	       if (!hasValue(str)) {
	           return false;
	       }
	       if (str.charAt(str.length() - 1) == '.') {
	           return false;
	       }
	       if (str.charAt(0) == '-') {
	           if (str.length() == 1) {
	               return false;
	           }
	           return withDecimalsParsing(str, 1);
	       }
	       return withDecimalsParsing(str, 0);
	   }
	
	private static boolean withDecimalsParsing(final String str, final int beginIdx) {
        int decimalPoints = 0;
        for (int i = beginIdx; i < str.length(); i++) {
            final boolean isDecimalPoint = str.charAt(i) == '.';
            if (isDecimalPoint) {
                decimalPoints++;
            }
            if (decimalPoints > 1) {
                return false;
            }
            if (!isDecimalPoint && !Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }
	
	public static BigDecimal convertToBigDecimal(Object objValue, int decimalPrecision) {
		if(objValue == null) {
			return null;
		}
		BigDecimal returnValue = null;
		if(objValue instanceof BigDecimal) {
			returnValue = (BigDecimal) objValue;
			returnValue = returnValue.setScale(decimalPrecision, RoundingMode.HALF_UP);
		} else if(objValue instanceof BigInteger) {
			returnValue = new BigDecimal((BigInteger) objValue).setScale(decimalPrecision, RoundingMode.HALF_UP);
		} else if(objValue instanceof Integer) {
			returnValue = new BigDecimal((Integer) objValue).setScale(decimalPrecision, RoundingMode.HALF_UP);
		} else if(objValue instanceof Long) {
			returnValue = new BigDecimal((Long) objValue).setScale(decimalPrecision, RoundingMode.HALF_UP);
		} else if(objValue instanceof Float) {
			returnValue = new BigDecimal(Float.toString((Float) objValue)).setScale(decimalPrecision, RoundingMode.HALF_UP);
		} else if(objValue instanceof Double) {
			returnValue = new BigDecimal( Double.toString((Double) objValue)).setScale(decimalPrecision, RoundingMode.HALF_UP);
		}
		return returnValue;
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T cast(Object obj) {
	    return (T)obj;
	}
	
	//convertStringListTodoubleList(ageOrder,Double::parseDouble).toArray(new Double[0]);
	public static <T, U> List<U> convertStringListTodoubleList(List<T> listOfString, Function<T, U> function) {
		return listOfString.stream().map(function).collect(Collectors.toList());
	}
	
	public static <T> List<T[]> twoDArrayToList(T[][] twoDArray) {
	    List<T[]> list = new ArrayList<>();
	    for (T[] array : twoDArray) {
	        list.add(array);
	    }
	    return list;
	}
	
	public static String getBlankIfNull(Object value) {
		if(value == null)
			return "";
		return value.toString();
	}
}
