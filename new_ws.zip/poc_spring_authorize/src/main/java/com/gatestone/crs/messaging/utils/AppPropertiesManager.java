package com.gatestone.crs.messaging.utils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AppPropertiesManager {
	
	private static final String ERROR_LOG_TEXT = "Number format exception for key {} and value {}";

	@Autowired
    private Environment env;
    
    public String getProperty(String key) {
        return env.getProperty(key);
    }
    
    public int getPropertyIntPrimitive(String key, int defaultValue) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			try {
				return Integer.parseInt(strValue.trim());
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);	
			}
		}
		return defaultValue;
	}
	
	public Integer getPropertyInteger(String key) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			try {
				return Integer.valueOf(strValue.trim());
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);	
			}
		}
		return null;
	}
	
	public long getPropertyLongPrimitive(String key, long defaultValue) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			try {
				return Long.parseLong(strValue.trim());
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);	
			}
		}
		return defaultValue;
	}
	
	public Long getPropertyLong(String key) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			try {
				return Long.valueOf(strValue.trim());
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);	
			}
		}
		return null;
	}
	
	public double getPropertyDoublePrimitive(String key, double defaultValue) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			try {
				return Double.parseDouble(strValue.trim());
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);	
			}
		}
		return defaultValue;
	}
	
	public Double getPropertyDouble(String key) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			try {
				return Double.valueOf(strValue.trim());
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);	
			}
		}
		return null;
	}
	
	public boolean getPropertyBoolean(String key, boolean defaultValue) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			return "Y".equalsIgnoreCase(strValue.trim()) || "true".equalsIgnoreCase(strValue.trim());
		}
		return defaultValue;
	}
	
	public Boolean getPropertyBooleanObject(String key) {
		String strValue = env.getProperty(key);
		if(StringUtils.isNotBlank(strValue)) {
			return "Y".equalsIgnoreCase(strValue.trim()) || "true".equalsIgnoreCase(strValue.trim());
		}
		return null;
	}
}
