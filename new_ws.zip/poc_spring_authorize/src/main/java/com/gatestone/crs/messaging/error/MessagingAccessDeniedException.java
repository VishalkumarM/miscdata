package com.gatestone.crs.messaging.error;

public class MessagingAccessDeniedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8775218308982395317L;

	public MessagingAccessDeniedException(String message) {
		super(message);
	}
	
	public MessagingAccessDeniedException(Throwable cause) {
        super(cause);
    }
	
	public MessagingAccessDeniedException(String message, Throwable cause) {
        super(message, cause);
    }
}
