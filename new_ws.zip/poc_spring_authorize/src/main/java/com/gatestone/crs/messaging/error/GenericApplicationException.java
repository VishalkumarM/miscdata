package com.gatestone.crs.messaging.error;

public class GenericApplicationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6546256393238219196L;

	public GenericApplicationException(String message) {
		super(message);
	}
	
	public GenericApplicationException(Throwable cause) {
        super(cause);
    }
	
	public GenericApplicationException(String message, Throwable cause) {
        super(message, cause);
    }
}
