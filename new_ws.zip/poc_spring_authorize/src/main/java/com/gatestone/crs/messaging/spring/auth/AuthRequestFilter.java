package com.gatestone.crs.messaging.spring.auth;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.gatestone.crs.messaging.error.MessagingAccessDeniedException;
import com.gatestone.crs.messaging.model.enums.AuthServiceType;
import com.gatestone.crs.messaging.model.enums.ServiceStatus;
import com.gatestone.crs.messaging.spring.auth.JwtUtil.JwtParserBuilder;
import com.gatestone.crs.messaging.spring.auth.model.Action;
import com.gatestone.crs.messaging.utils.CookieHelper;

import groovy.json.JsonSlurper;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AuthRequestFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final UserAccountDetailsService userDetailsService;

    public AuthRequestFilter(JwtUtil jwtUtil, UserAccountDetailsService myUserDetailsService) {
        this.jwtUtil = jwtUtil;
        this.userDetailsService = myUserDetailsService;
    }
    
    @PostConstruct
    public void init() {
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        final String authorizationHeader = request.getHeader("Authorization");
        if (authorizationHeader != null) {
            if (authorizationHeader.startsWith("Bearer ")) {
                handleJwtAuth(authorizationHeader, request);
            } else if (authorizationHeader.startsWith("Basic ")) {
                handleBasicAuth(authorizationHeader, request);
            }
        } else {
            // Handle cookie based auth
            handleCookieAuth(request);
        }
        chain.doFilter(request, response);
    }
    
    @SuppressWarnings("unchecked")
    private UserAccountDetail getDetailsFromCookie(HttpServletRequest request) {
    	CookieHelper helper = new CookieHelper();
    	UserAccountDetail details = null;
    	String data =  helper.extractSecureCookie(request, CookieHelper.COOKIE_NAME, true, true);
    	if(data != null) {
    		Map<String, Object> detailsJson = (Map<String, Object>) new JsonSlurper().parseText(data);
    		UserAccountDetail tmpBean = new UserAccountDetail();
    		tmpBean.setType(AuthServiceType.COOKIE);
    		tmpBean.setStatus(ServiceStatus.ACTIVE);
    		tmpBean.setEin((String) detailsJson.get("ein"));
    		tmpBean.setEmail((String) detailsJson.get("email"));
    		
    		List<String> actions = (List<String>) detailsJson.get("actions");
    		if(actions !=  null) {
    			List<Action> actionsTmp = new ArrayList<Action>();
    			tmpBean.setActions(actionsTmp);
    			Action act = null;
    			for(String action : actions) {
    				act = new Action();
    				act.setAction(action);
    				actionsTmp.add(act);
    			}
    		}
    		
    		details = tmpBean;
    	}
    	return details;
    }
    
    private void handleCookieAuth(HttpServletRequest request) {
        try {
        	UserDetails userDetails = getDetailsFromCookie(request);
            if (userDetails != null) {
            	authenticateUser(userDetails, request);
            }
        } catch (Exception e) {
            //throw new MessagingAccessDeniedException("Invalid URL Authentication", e);
        	log.error("Invalid Authentication", e);
        }
    }

    private void handleJwtAuth(String authorizationHeader, HttpServletRequest request) {
        JwtParserBuilder jwtBuilder = null;
        String username = null;
        String jwt = authorizationHeader.substring(7);
        
        try {
            jwtBuilder = jwtUtil.newJwtParser(jwt);
            if(jwtBuilder.isTokenExpired()) {
                throw new MessagingAccessDeniedException("Invalid Authorization");
            }
            username = jwtBuilder.extractUsername();
            
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                //UserDetails userDetails = userDetailsService1.loadUserByUsername(username);
                
                //check validity of jwt token
                //authenticateUser(userDetails, request);
                
                /*PublicKey key = getOrLoadPublicKey(auId);
                if (jwtBuilder.isSignatureValid(key)) {
                    authenticateUser(userDetails, request);
                } else {
                    throw new MessagingAccessDeniedException("Invalid Authorization");
                }*/
            }
        } catch (Exception e) {
            throw new MessagingAccessDeniedException("Invalid Authorization");
        }
    }

    private void handleBasicAuth(String authorizationHeader, HttpServletRequest request) {
        try {
            String base64Credentials = authorizationHeader.substring("Basic ".length()).trim();
            byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
            String credentials = new String(credDecoded, StandardCharsets.UTF_8);
            
            final String[] values = credentials.split(":", 2);
            if (values.length != 2) {
                throw new MessagingAccessDeniedException("Invalid Basic Authentication");
            }
            
            String username = values[0];
            String password = values[1];
            
            UserDetails userDetails = userDetailsService.loadUserByUsername(username);
            if(userDetails instanceof UserAccountDetail userAccount) {
            	
            	if(userAccount.getType() != AuthServiceType.PASSWORD) {
            		 throw new MessagingAccessDeniedException("Invalid Authentication Scheme");
            	}
            }
            if (verifyPassword(password, userDetails)) {
                authenticateUser(userDetails, request);
            } else {
                throw new MessagingAccessDeniedException("Invalid credentials");
            }
            
        } catch (Exception e) {
        	e.printStackTrace();
            throw new MessagingAccessDeniedException("Invalid Basic Authentication");
        }
    }
    
    private PublicKey getOrLoadPublicKey(String pubKey) throws ServletException {
        PublicKey key = null;
        try {
        	key = jwtUtil.rsaPublicKeyParser(pubKey);
        } catch (Exception e) {
            throw new ServletException(e);
        }
        if(key == null) {
            throw new MessagingAccessDeniedException("Invalid Authorization");
        }
        return key;
    }

    private void authenticateUser(UserDetails userDetails, HttpServletRequest request) {
        
    	UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
    	authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
        
        System.out.println("################################### AUTH ::: "+ userDetails.getUsername());
        
//      SecurityContext context = SecurityContextHolder.getContext();
//		context.setAuthentication(authenticationToken);
//		SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
//		securityContextHolderStrategy.setContext(context);
        
    }

    private boolean verifyPassword(String password, UserDetails userDetails) throws Exception {
       // return EncryptionUtils.verifyPassword(userDetails.getPassword(), password); // Replace with actual implementation
    	return true;
    }
}
