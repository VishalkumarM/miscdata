package com.gatestone.crs.messaging.utils;

import java.util.MissingResourceException;
import java.util.Properties;
import java.util.ResourceBundle;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PropertyUtils {
	
	private static final String ERROR_LOG_TEXT = "Number format exception for key {} and value {}";
	
	private PropertyUtils() {
		//
	}

	public static final String getProperty(String propertyFile, String key) {
		String value = System.getProperty(key);
		if(ApplicationUtils.isNotBlank(value))
			return value;
		ResourceBundle resourceBundle = ResourceBundle.getBundle(propertyFile);
		try {
			return resourceBundle.getString(key);
		} catch (MissingResourceException e) {
			return null;
		}
	}
	
	public static int getPropertyIntPrimitive(String propertyFile, String key, int defaultValue) {
		String strValue = getProperty(propertyFile, key);
		if(ApplicationUtils.isNotBlank(strValue)) {
			try {
				return Integer.parseInt(strValue);
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);
			}
		}
		return defaultValue;
	}
	
	public static Integer getPropertyInteger(String propertyFile, String key) {
		String strValue = getProperty(propertyFile, key);
		if(ApplicationUtils.isNotBlank(strValue)) {
			try {
				return Integer.valueOf(strValue);
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);
			}
		}
		return null;
	}
	
	public static long getPropertyLongPrimitive(String propertyFile, String key, long defaultValue) {
		String strValue = getProperty(propertyFile, key);
		if(ApplicationUtils.isNotBlank(strValue)) {
			try {
				return Long.parseLong(strValue);
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);
			}
		}
		return defaultValue;
	}
	
	public static Long getPropertyLong(String propertyFile, String key) {
		String strValue = getProperty(propertyFile, key);
		if(ApplicationUtils.isNotBlank(strValue)) {
			try {
				return Long.valueOf(strValue);
			} catch (NumberFormatException ex) {
				log.error(ERROR_LOG_TEXT, key, strValue);
			}
		}
		return null;
	}
	
	public static boolean getPropertyBoolean(String propertyFile, String key, boolean defaultValue) {
		String strValue = getProperty(propertyFile, key);
		if(ApplicationUtils.isNotBlank(strValue)) {
			return "Y".equalsIgnoreCase(strValue) || "true".equalsIgnoreCase(strValue);
		}
		return defaultValue;
	}
	
	public static Boolean getPropertyBooleanObject(String propertyFile, String key) {
		String strValue = getProperty(propertyFile, key);
		if(ApplicationUtils.isNotBlank(strValue)) {
			return "Y".equalsIgnoreCase(strValue) || "true".equalsIgnoreCase(strValue);
		}
		return null;
	}
	
	public static Properties getPrefixed(String propertyFile, String prefix) {
		int len = prefix.length();
		ResourceBundle resourceBundle = ResourceBundle.getBundle(propertyFile);
		Properties props = new Properties();
		for(String key : resourceBundle.keySet()) {
			if(key.startsWith(prefix)) {
				props.put(key.substring(len), resourceBundle.getString(key));
			}
		}
		return props;
	}
}
