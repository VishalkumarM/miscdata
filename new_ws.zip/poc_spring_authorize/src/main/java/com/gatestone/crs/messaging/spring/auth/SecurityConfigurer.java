package com.gatestone.crs.messaging.spring.auth;

import java.util.function.Function;

import org.springframework.aop.Advisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Role;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authorization.method.AuthorizationManagerBeforeMethodInterceptor;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableWebSecurity
//@EnableMethodSecurity(prePostEnabled = false)
public class SecurityConfigurer {

    @Autowired
    private AuthRequestFilter jwtRequestFilter;
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    	return http
        .csrf(cs -> cs.disable())
        .cors(cs -> cs.disable())
        .formLogin(fl -> fl.disable())
        .httpBasic(hb -> hb.disable())
        .authorizeHttpRequests(authorizeHttpRequests -> authorizeHttpRequests
        		.requestMatchers("/api/public/**").permitAll()
        		.requestMatchers("/ui/**").permitAll()
        		.anyRequest().authenticated() // Protect other endpoints
        ) // Allow unauthenticated access to certain endpoints
        .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Stateless API
    	.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class)
    	.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }
    
//    @Bean
//    public AuthorizationManager<HttpServletRequest> customAuthorizationManager(CustomAuthorizationManager customAuthorizationManager) {
//        return (authentication, object) -> customAuthorizationManager.check(authentication, object);
//    }
    
    @Bean
    public Function<UserDetails, UserAccountDetail> fetchUser() {
      return (principal -> {
      	log.debug("AUTH USER :: "+principal);
      	log.debug("AUTH USER-Name :: "+principal.getUsername());
      	//do JPA logic
      	return (UserAccountDetail) principal;
      });
    }
}