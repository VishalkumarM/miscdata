package com.gatestone.crs.messaging.model;

public interface IGenericParsableBean {

}
