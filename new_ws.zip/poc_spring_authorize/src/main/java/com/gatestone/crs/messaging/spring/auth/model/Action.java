package com.gatestone.crs.messaging.spring.auth.model;

import org.springframework.security.core.GrantedAuthority;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Action implements GrantedAuthority {

	private String action;
	
	@Override
	public String getAuthority() {
		return action;
	}
}
