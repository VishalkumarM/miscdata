package com.gatestone.crs.messaging.spring.auth;

import java.util.function.Supplier;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.gatestone.crs.messaging.spring.auth.annotations.PartialSecuredResource;
import com.gatestone.crs.messaging.spring.auth.annotations.SecuredResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Lazy
@Component("customAuthorizationManager")
@ConditionalOnProperty(name = "secure.annotation.enabled", havingValue = "true", matchIfMissing = false) // optional, default is false
public class CustomMethodAuthorizationManager implements AuthorizationManager<MethodInvocation> {


    @Override
    public AuthorizationDecision check(Supplier<Authentication> authentication, MethodInvocation invocation) {
    	
    	SecuredResource securedRes = invocation.getMethod().getAnnotation(SecuredResource.class);
    	PartialSecuredResource partSecuredRes = invocation.getMethod().getAnnotation(PartialSecuredResource.class);
    	boolean granted = Boolean.TRUE;
    	
    	UserAccountDetail authUser = (UserAccountDetail) authentication.get().getPrincipal();
    	//ICustomAuthentication custAuth = (ICustomAuthentication) authentication.get();
//    	Long authState = custAuth.getState();
//    	boolean isFullyAuthenticated = UserLoginSession.STATUS_FULLY_AUTHENTICATED.equals(authState);
//    	boolean isSecured = isFullyAuthenticated; 
    	
    	if(securedRes != null || partSecuredRes != null) {
    		if(authUser == null) {
    			granted = Boolean.FALSE;
    		} else {
    			String[] actions = securedRes != null? securedRes.roles() : partSecuredRes.roles();
    			if(actions.length > 0) {
    				//authUser.getAuthorities();
    				granted = Boolean.FALSE;
    				for(String action : actions) {
    					if(hasRequiredAuthority(authentication.get(), action)) {
    					//if(authUser.getAuthorities().contains(action)) {
    						granted = Boolean.TRUE;
    						break;
    					}
    				}
    			}
    		}
    	}
    	
        return new AuthorizationDecision(granted);
    }
    
    public boolean hasRequiredAuthority(Authentication authentication, String requiredAuthority) {
        return authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(authority -> authority.equals(requiredAuthority));
    }
}