package com.gatestone.crs.messaging.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum AuthServiceType implements IGenericEnum<String> {
    OAUTH("1", "oAuth"), PASSWORD("2", "PASSWORD"), COOKIE("3", "COOKIE");
	
    private static final Map<String, AuthServiceType> lookup = new HashMap<>();
    static {
        for (AuthServiceType d : AuthServiceType.values()) {
            lookup.put(d.getCode(), d);
        }
    }

    private String code;
    private String description;

    private AuthServiceType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }
    
    public String getDescription() {
    	return description;
    }
    
    public AuthServiceType get(String code) {
        return doLokup(code);
    }
    
    public static AuthServiceType doLokup(String code) {
        return lookup.get(code);
    }
}
