package com.gatestone.crs.messaging.constants;

public class ApplicationConstants {
	
	public static final String API_PRRFIX = "/api";
	public static final String PUBLIC_API_PRRFIX = "/public";

}
