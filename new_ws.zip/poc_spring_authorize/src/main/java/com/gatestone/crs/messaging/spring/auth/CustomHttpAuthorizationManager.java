package com.gatestone.crs.messaging.spring.auth;

import java.util.function.Supplier;

import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import jakarta.servlet.http.HttpServletRequest;

public class CustomHttpAuthorizationManager implements AuthorizationManager<HttpServletRequest> {

	@Override
	public AuthorizationDecision check(Supplier<Authentication> authentication, HttpServletRequest request) {
		boolean granted = Boolean.TRUE;

		UserAccountDetail authUser = (UserAccountDetail) authentication.get().getPrincipal();
		// ICustomAuthentication custAuth = (ICustomAuthentication)
		// authentication.get();
//    	Long authState = custAuth.getState();
//    	boolean isFullyAuthenticated = UserLoginSession.STATUS_FULLY_AUTHENTICATED.equals(authState);
//    	boolean isSecured = isFullyAuthenticated; 

		String urlWithoutQuery = request.getRequestURI();

		if (authUser == null) {
			granted = Boolean.FALSE;
		} else {
			granted = Boolean.FALSE;
			if (hasRequiredAuthority(authentication.get(), urlWithoutQuery)) {
				granted = Boolean.TRUE;
			}
		}

		return new AuthorizationDecision(granted);
	}

	public boolean hasRequiredAuthority(Authentication authentication, String requiredAuthority) {
		return authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority)
				.anyMatch(authority -> requiredAuthority.contains(authority));
	}
}
