package com.gatestone.crs.messaging.spring.auth;

import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
import org.springframework.security.core.Authentication;

import jakarta.servlet.http.HttpServletRequest;

public class CustomMethodSecurityExpressionRoot extends SecurityExpressionRoot implements MethodSecurityExpressionOperations {

//    private RoleRepository roleService;
    //No idea why these are needed. Just followed the guide
    private HttpServletRequest request;
    private Object filterObject;
    private Object returnObject;
    private Object target;

    public CustomMethodSecurityExpressionRoot(Authentication authentication) {
        super(authentication);
    }
    
    //Here is where you add the methods you'll be using in @PreAuthorize together with their logic

    //Custom method you'll be using in @PreAuthorize
    public boolean partOfBU(Long buIdToCheck){
        //your logic
    	return true;
    }
    
    //Custom method you'll be using in @PreAuthorize
    public boolean authorityCheck(Long buIdToCheck, String authorityToCheck){
        //your logic
    	return true;
    }

//    public void setRoleService(RoleRepository roleService){
//        this.roleService = roleService;
//    }

    @Override
    public void setFilterObject(Object filterObject) {
        this.filterObject = filterObject;
    }

    @Override
    public Object getFilterObject() {
        return this.filterObject;
    }

    @Override
    public void setReturnObject(Object returnObject) {
        this.returnObject = returnObject;
    }

    @Override
    public Object getReturnObject() {
        return this.returnObject;
    }

    @Override
    public Object getThis() {
        return target;
    }
}
