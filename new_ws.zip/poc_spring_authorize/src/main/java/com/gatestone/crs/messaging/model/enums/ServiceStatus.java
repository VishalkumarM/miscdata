package com.gatestone.crs.messaging.model.enums;

import java.util.HashMap;
import java.util.Map;

public enum ServiceStatus implements IGenericEnum<String> {
    ACTIVE("A", "Active"), SUSPENDED("S", "Suspended"), DISABLED("D", "Disabled");
	
    private static final Map<String, ServiceStatus> lookup = new HashMap<>();
    static {
        for (ServiceStatus d : ServiceStatus.values()) {
            lookup.put(d.getCode(), d);
        }
    }

    private String code;
    private String description;

    private ServiceStatus(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }
    
    public String getDescription() {
    	return description;
    }
    
    public ServiceStatus get(String code) {
        return doLokup(code);
    }
    
    public static ServiceStatus doLokup(String code) {
        return lookup.get(code);
    }
    
}
