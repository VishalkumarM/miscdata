package com.gatestone.crs.messaging.spring.auth;

import java.security.MessageDigest;
import java.security.Security;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.fasterxml.jackson.annotation.JsonValue;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EncryptionUtils {
	
	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	
	public enum Algo {
		SHA1("SHA1", ALGORITHM_SHA1), SHA2("SHA2", ALGORITHM_SHA256);
		
		private static final Map<String, Algo> lookup = new HashMap<>();
		static {
			for (Algo d : Algo.values()) {
				lookup.put(d.getCode(), d);
			}
		}

		private String code;
		private String description;

		private Algo(String code, String description) {
			this.code = code;
			this.description = description;
		}

		public String getCode() {
			return code;
		}

		@JsonValue
		public String getDescription() {
			return description;
		}

		public Algo get(String code) {
			return doLokup(code);
		}

		public static Algo doLokup(String code) {
			return lookup.get(code);
		}
		
		@Override
		public String toString() {
			return this.getDescription();
		}
	}
	
	public static final String ALGORITHM_SHA1= "SHA-1";
	public static final String ALGORITHM_SHA256 = "SHA-256";
	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toLowerCase().toCharArray();

	private static String doHash(String algorithm, String input) {
		try {
			MessageDigest md = MessageDigest.getInstance(algorithm);
			byte[] lBytes = md.digest(input.getBytes());
			return HexFormat.of().formatHex(lBytes);
		} catch (Exception ex) {
			log.error("ERR ALG {} INP {}", algorithm, input);
			log.error("ERR", ex);
		}
		return null;
	}
	
	public static String bytesToHex(byte[] bytes) {
	    char[] hexChars = new char[bytes.length * 2];
	    for (int j = 0; j < bytes.length; j++) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = HEX_ARRAY[v >>> 4];
	        hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
	    }
	    return new String(hexChars);
	}
	
	public static String encryptPassword(String inputPassword, Algo algo) throws Exception {
		switch(algo) {
			case SHA1: 
			case SHA2: return "["+algo.getCode()+"] " + doHash(algo.getDescription(), inputPassword);
			default: return inputPassword;
		}
	}
	
	public static boolean verifyPassword(String dbPassword, String inputPassword) throws Exception {
		if (dbPassword == null)
			return false;
		String extract = getMatchingGroup("^(\\[.+\\] ).+$", dbPassword, 1);
		if (extract != null) {
			String encPass = dbPassword.substring(extract.length());
			String encPassInp = null;
			if ("[SHA1]".equals(extract.trim())) {
				encPassInp = doHash(ALGORITHM_SHA1, inputPassword);
			} else if ("[SHA2]".equals(extract.trim())) {
				encPassInp = doHash(ALGORITHM_SHA256, inputPassword);
			}
			return encPass.equals(encPassInp);
		}
		return false;
	}
	
	public static  String getMatchingGroup(String patternRegex, String strCurrentLine, int group) {
		Pattern pattern = Pattern.compile(patternRegex);
		Matcher matcher = pattern.matcher(strCurrentLine);
		String key = null;
		if (matcher.find()) {
			key = matcher.group(group);
		}
		return key;
	}

}
