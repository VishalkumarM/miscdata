CREATE DATABASE  IF NOT EXISTS `crssmsgateway` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `crssmsgateway`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: crssmsgateway
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actions` (
  `ACId` bigint NOT NULL AUTO_INCREMENT,
  `ACAction` varchar(100) NOT NULL,
  PRIMARY KEY (`ACId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES (2,'SMS.SEND'),(3,'SMS.LIST'),(4,'SMS.UPD');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apiuserauthconfigs`
--

DROP TABLE IF EXISTS `apiuserauthconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apiuserauthconfigs` (
  `UACId` bigint NOT NULL AUTO_INCREMENT,
  `UACUaId` bigint NOT NULL,
  `UACType` varchar(2) NOT NULL,
  `UACStatus` varchar(2) NOT NULL,
  `UACConfig` varchar(5000) NOT NULL,
  `UACUserName` varchar(5000) DEFAULT NULL,
  `UACPassword` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`UACId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apiuserauthconfigs`
--

LOCK TABLES `apiuserauthconfigs` WRITE;
/*!40000 ALTER TABLE `apiuserauthconfigs` DISABLE KEYS */;
INSERT INTO `apiuserauthconfigs` VALUES (1,1,'2','A','NA','apiamexca','[SHA2] 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),(2,1,'2','A','NA','twiliouser','[SHA2] 8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92');
/*!40000 ALTER TABLE `apiuserauthconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crsallowedproviences`
--

DROP TABLE IF EXISTS `crsallowedproviences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crsallowedproviences` (
  `CAPId` bigint NOT NULL AUTO_INCREMENT,
  `CAPActive` varchar(1) NOT NULL,
  `CAPName` varchar(50) NOT NULL,
  PRIMARY KEY (`CAPId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crsallowedproviences`
--

LOCK TABLES `crsallowedproviences` WRITE;
/*!40000 ALTER TABLE `crsallowedproviences` DISABLE KEYS */;
INSERT INTO `crsallowedproviences` VALUES (1,'Y','ON');
/*!40000 ALTER TABLE `crsallowedproviences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crsproviencetimings`
--

DROP TABLE IF EXISTS `crsproviencetimings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crsproviencetimings` (
  `CPTId` bigint NOT NULL AUTO_INCREMENT,
  `CPTActive` varchar(1) NOT NULL,
  `CPTName` varchar(50) NOT NULL,
  `CPTTimeZone` varchar(50) NOT NULL,
  `CPTStartTimeMonday` varchar(8) DEFAULT NULL,
  `CPTEndTimeMonday` varchar(8) DEFAULT NULL,
  `CPTStartTimeTuesday` varchar(8) DEFAULT NULL,
  `CPTEndTimeTuesday` varchar(8) DEFAULT NULL,
  `CPTStartTimeWednesday` varchar(8) DEFAULT NULL,
  `CPTEndTimeWednesday` varchar(8) DEFAULT NULL,
  `CPTStartTimeThursday` varchar(8) DEFAULT NULL,
  `CPTEndTimeThursday` varchar(8) DEFAULT NULL,
  `CPTStartTimeFriday` varchar(8) DEFAULT NULL,
  `CPTEndTimeFriday` varchar(8) DEFAULT NULL,
  `CPTStartTimeSaturday` varchar(8) DEFAULT NULL,
  `CPTEndTimeSaturday` varchar(8) DEFAULT NULL,
  `CPTStartTimeSunday` varchar(8) DEFAULT NULL,
  `CPTEndTimeSunday` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`CPTId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crsproviencetimings`
--

LOCK TABLES `crsproviencetimings` WRITE;
/*!40000 ALTER TABLE `crsproviencetimings` DISABLE KEYS */;
INSERT INTO `crsproviencetimings` VALUES (1,'Y','DEFAULT','America/Toronto','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00',NULL,NULL),(2,'Y','ON','America/Toronto','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00',NULL,NULL);
/*!40000 ALTER TABLE `crsproviencetimings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roleactions`
--

DROP TABLE IF EXISTS `roleactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roleactions` (
  `RAId` bigint NOT NULL AUTO_INCREMENT,
  `RAROId` bigint NOT NULL,
  `RAACId` bigint NOT NULL,
  PRIMARY KEY (`RAId`),
  KEY `roleactions_roid_acid` (`RAROId`,`RAACId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roleactions`
--

LOCK TABLES `roleactions` WRITE;
/*!40000 ALTER TABLE `roleactions` DISABLE KEYS */;
INSERT INTO `roleactions` VALUES (2,2,2),(4,2,3),(5,3,4);
/*!40000 ALTER TABLE `roleactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `ROId` bigint NOT NULL AUTO_INCREMENT,
  `ROName` varchar(100) NOT NULL,
  PRIMARY KEY (`ROId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (2,'CRS_SMS_SEND'),(3,'CRS_SMS_UPDATE');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessagerequests`
--

DROP TABLE IF EXISTS `smsmessagerequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessagerequests` (
  `SMRQId` varchar(50) NOT NULL,
  `SMRQSmId` varchar(50) NOT NULL,
  `SMRQPayload` varchar(5000) NOT NULL,
  `SMRQCreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`SMRQId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessagerequests`
--

LOCK TABLES `smsmessagerequests` WRITE;
/*!40000 ALTER TABLE `smsmessagerequests` DISABLE KEYS */;
INSERT INTO `smsmessagerequests` VALUES ('071d4b81-0564-4c66-9079-8492d221956e','fb3d8b33-5ef7-4bcb-a8db-01905b34f240','{\"headers\":{\"Authorization\":\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\"},\"method\":\"POST\",\"params\":[{\"name\":\"To\",\"value\":\"+919987092183\"},{\"name\":\"Body\",\"value\":\"Hello World3\"},{\"name\":\"StatusCallback\",\"value\":\"https://twiliouser:pass_123@messaging.gatestone.com/api/webhook/status/fb3d8b33-5ef7-4bcb-a8db-01905b34f240\"},{\"name\":\"From\",\"value\":\"+15005550006\"}],\"hdr\":\"{\\\"Authorization\\\":\\\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\\\"}\"}','2025-01-12 00:33:05.036000'),('2c46ded5-2992-4329-a274-5f2ec4f59824','253db50e-8b33-466c-b912-9001e6670748','{\"headers\":{\"Authorization\":\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\"},\"method\":\"POST\",\"params\":[{\"name\":\"To\",\"value\":\"+919987092183\"},{\"name\":\"Body\",\"value\":\"Hello World2\"},{\"name\":\"StatusCallback\",\"value\":\"https://twiliouser:pass_123@messaging.gatestone.com/api/webhook/status/253db50e-8b33-466c-b912-9001e6670748\"},{\"name\":\"From\",\"value\":\"+15005550006\"}],\"hdr\":\"{\\\"Authorization\\\":\\\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\\\"}\"}','2025-01-12 00:33:04.744000'),('5b74a935-15c5-44ff-aff4-c85de44f31d3','e0a81c1c-7a30-423a-8ad3-b931d3071141','{\"headers\":{\"Authorization\":\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\"},\"method\":\"POST\",\"params\":[{\"name\":\"To\",\"value\":\"+919987092183\"},{\"name\":\"Body\",\"value\":\"Hello World5\"},{\"name\":\"StatusCallback\",\"value\":\"https://twiliouser:pass_123@messaging.gatestone.com/api/webhook/status/e0a81c1c-7a30-423a-8ad3-b931d3071141\"},{\"name\":\"From\",\"value\":\"+15005550006\"}],\"hdr\":\"{\\\"Authorization\\\":\\\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\\\"}\"}','2025-01-12 00:33:05.663000'),('5e42cf43-c4f2-4bce-9563-cc084c99145d','c9d6c4d7-a055-43c6-8fec-a5153775f8df','{\"headers\":{\"Authorization\":\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\"},\"method\":\"POST\",\"params\":[{\"name\":\"To\",\"value\":\"+919987092183\"},{\"name\":\"Body\",\"value\":\"Hello World4\"},{\"name\":\"StatusCallback\",\"value\":\"https://twiliouser:pass_123@messaging.gatestone.com/api/webhook/status/c9d6c4d7-a055-43c6-8fec-a5153775f8df\"},{\"name\":\"From\",\"value\":\"+15005550006\"}],\"hdr\":\"{\\\"Authorization\\\":\\\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\\\"}\"}','2025-01-12 00:33:05.362000'),('6b21819b-69e6-4510-be06-dbb372cbf583','eb1fcbad-c4ba-4b91-b57a-7f0dfe7915bb','{\"headers\":{\"Authorization\":\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\"},\"method\":\"POST\",\"params\":[{\"name\":\"To\",\"value\":\"+919987092183\"},{\"name\":\"Body\",\"value\":\"Hello World0\"},{\"name\":\"StatusCallback\",\"value\":\"https://twiliouser:pass_123@messaging.gatestone.com/api/webhook/status/eb1fcbad-c4ba-4b91-b57a-7f0dfe7915bb\"},{\"name\":\"From\",\"value\":\"+15005550006\"}],\"hdr\":\"{\\\"Authorization\\\":\\\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\\\"}\"}','2025-01-12 00:33:04.069000'),('dfe6ea74-c5ce-461c-b413-a21ffcd246be','38f50931-a8db-40d4-b635-a3fb56b23335','{\"headers\":{\"Authorization\":\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\"},\"method\":\"POST\",\"params\":[{\"name\":\"To\",\"value\":\"+919987092183\"},{\"name\":\"Body\",\"value\":\"Hello World1\"},{\"name\":\"StatusCallback\",\"value\":\"https://twiliouser:pass_123@messaging.gatestone.com/api/webhook/status/38f50931-a8db-40d4-b635-a3fb56b23335\"},{\"name\":\"From\",\"value\":\"+15005550006\"}],\"hdr\":\"{\\\"Authorization\\\":\\\"Basic QUMxMjIwZWY5NTM4N2U5OTEyN2EwNGFlNjc3ZmI5ZGE5MjowY2MwMDQwYWEwZGJiMzc0NTMxNWQ4OWEwMGIxOGNmNA==\\\"}\"}','2025-01-12 00:33:04.418000');
/*!40000 ALTER TABLE `smsmessagerequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessageresponses`
--

DROP TABLE IF EXISTS `smsmessageresponses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessageresponses` (
  `SMRSId` varchar(50) NOT NULL,
  `SMRSSmId` varchar(50) NOT NULL,
  `SMRSSmReqId` varchar(50) NOT NULL,
  `SMRSNumberOfMessages` varchar(2) DEFAULT NULL,
  `SMRSPayload1` varchar(5000) NOT NULL,
  `SMRSPayload2` varchar(5000) DEFAULT NULL,
  `SMRSServiceMsgId` varchar(255) DEFAULT NULL,
  `SMRSStatus` varchar(50) DEFAULT NULL,
  `SMRSCreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`SMRSId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessageresponses`
--

LOCK TABLES `smsmessageresponses` WRITE;
/*!40000 ALTER TABLE `smsmessageresponses` DISABLE KEYS */;
INSERT INTO `smsmessageresponses` VALUES ('061f8dcc-a5db-4c42-aaf1-5fe713bb9735','e0a81c1c-7a30-423a-8ad3-b931d3071141','5b74a935-15c5-44ff-aff4-c85de44f31d3','1','{\"statusCode\":201,\"responseText\":\"{\\\"account_sid\\\": \\\"AC1220ef95387e99127a04ae677fb9da92\\\", \\\"api_version\\\": \\\"2010-04-01\\\", \\\"body\\\": \\\"Hello World5\\\", \\\"date_created\\\": \\\"Sat, 11 Jan 2025 19:03:03 +0000\\\", \\\"date_sent\\\": null, \\\"date_updated\\\": \\\"Sat, 11 Jan 2025 19:03:03 +0000\\\", \\\"direction\\\": \\\"outbound-api\\\", \\\"error_code\\\": null, \\\"error_message\\\": null, \\\"from\\\": \\\"+15005550006\\\", \\\"messaging_service_sid\\\": null, \\\"num_media\\\": \\\"0\\\", \\\"num_segments\\\": \\\"1\\\", \\\"price\\\": null, \\\"price_unit\\\": \\\"USD\\\", \\\"sid\\\": \\\"SM90716d12deaaeac61ab67502329f7077\\\", \\\"status\\\": \\\"queued\\\", \\\"subresource_uris\\\": {\\\"media\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM90716d12deaaeac61ab67502329f7077/Media.json\\\"}, \\\"to\\\": \\\"+919987092183\\\", \\\"uri\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM90716d12deaaeac61ab67502329f7077.json\\\"}\",\"error\":false,\"json\":true,\"headers\":{\"x-amz-cf-pop\":\"BOM78-P4\",\"date\":\"Sat, 11 Jan 2025 19:03:03 GMT\",\"content-length\":\"777\",\"access-control-allow-headers\":\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\",\"x-shenanigans\":\"none\",\"x-api-domain\":\"api.twilio.com\",\"twilio-request-duration\":\"0.049\",\"x-home-region\":\"us1\",\"access-control-allow-methods\":\"GET, POST, PATCH, PUT, DELETE, OPTIONS\",\"strict-transport-security\":\"max-age=31536000\",\"via\":\"1.1 9f3f4cadb8601c4fc66883a04796dbd0.cloudfront.net (CloudFront)\",\"access-control-expose-headers\":\"ETag, Twilio-Request-Id\",\"access-control-allow-origin\":\"*\",\"access-control-allow-credentials\":\"true\",\"x-powered-by\":\"AT-5000\",\"twilio-request-id\":\"RQ90716d12deaaeac61ab67502329f7077\",\"connection\":\"keep-alive\",\"content-type\":\"application/json;charset=utf-8\",\"x-cache\":\"Miss from cloudfront\",\"twilio-concurrent-requests\":\"1\",\"x-amz-cf-id\":\"7_3-7OLMADfeIXcSXVS2ukzLTsVDPyUlbAYcVc7ixvaMs-JMWScWcQ==\"},\"hdr\":\"{\\\"x-amz-cf-pop\\\":\\\"BOM78-P4\\\",\\\"date\\\":\\\"Sat, 11 Jan 2025 19:03:03 GMT\\\",\\\"content-length\\\":\\\"777\\\",\\\"access-control-allow-headers\\\":\\\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\\\",\\\"x-shenanigans\\\":\\\"none\\\",\\\"x-api-domain\\\":\\\"api.twilio.com\\\",\\\"twilio-request-duration\\\":\\\"0.049\\\",\\\"x-home-region\\\":\\\"us1\\\",\\\"access-control-allow-methods\\\":\\\"GET, POST, PATCH, PUT, DELETE, OPTIONS\\\",\\\"strict-transport-security\\\":\\\"max-age=31536000\\\",\\\"via\\\":\\\"1.1 9f3f4cadb8601c4fc66883a04796dbd0.cloudfront.net (CloudFront)\\\",\\\"access-control-expose-headers\\\":\\\"ETag, Twilio-Request-Id\\\",\\\"access-control-allow-origin\\\":\\\"*\\\",\\\"access-control-allow-credentials\\\":\\\"true\\\",\\\"x-powered-by\\\":\\\"AT-5000\\\",\\\"twilio-request-id\\\":\\\"RQ90716d12deaaeac61ab67502329f7077\\\",\\\"connection\\\":\\\"keep-alive\\\",\\\"content-type\\\":\\\"application/json;charset=utf-8\\\",\\\"x-cache\\\":\\\"Miss from cloudfront\\\",\\\"twilio-concurrent-requests\\\":\\\"1\\\",\\\"x-amz-cf-id\\\":\\\"7_3-7OLMADfeIXcSXVS2ukzLTsVDPyUlbAYcVc7ixvaMs-JMWScWcQ==\\\"}\"}',NULL,'SM90716d12deaaeac61ab67502329f7077','queued','2025-01-12 00:33:05.668000'),('5cc12f50-8945-4084-9b15-f962e0b0d589','eb1fcbad-c4ba-4b91-b57a-7f0dfe7915bb','6b21819b-69e6-4510-be06-dbb372cbf583','1','{\"statusCode\":201,\"responseText\":\"{\\\"account_sid\\\": \\\"AC1220ef95387e99127a04ae677fb9da92\\\", \\\"api_version\\\": \\\"2010-04-01\\\", \\\"body\\\": \\\"Hello World0\\\", \\\"date_created\\\": \\\"Sat, 11 Jan 2025 19:03:01 +0000\\\", \\\"date_sent\\\": null, \\\"date_updated\\\": \\\"Sat, 11 Jan 2025 19:03:01 +0000\\\", \\\"direction\\\": \\\"outbound-api\\\", \\\"error_code\\\": null, \\\"error_message\\\": null, \\\"from\\\": \\\"+15005550006\\\", \\\"messaging_service_sid\\\": null, \\\"num_media\\\": \\\"0\\\", \\\"num_segments\\\": \\\"1\\\", \\\"price\\\": null, \\\"price_unit\\\": \\\"USD\\\", \\\"sid\\\": \\\"SM7087cdf0aabc61d5ba81f1a932d57889\\\", \\\"status\\\": \\\"queued\\\", \\\"subresource_uris\\\": {\\\"media\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM7087cdf0aabc61d5ba81f1a932d57889/Media.json\\\"}, \\\"to\\\": \\\"+919987092183\\\", \\\"uri\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM7087cdf0aabc61d5ba81f1a932d57889.json\\\"}\",\"error\":false,\"json\":true,\"headers\":{\"x-amz-cf-pop\":\"BOM78-P4\",\"date\":\"Sat, 11 Jan 2025 19:03:01 GMT\",\"content-length\":\"777\",\"access-control-allow-headers\":\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\",\"x-shenanigans\":\"none\",\"x-api-domain\":\"api.twilio.com\",\"twilio-request-duration\":\"0.078\",\"x-home-region\":\"us1\",\"access-control-allow-methods\":\"GET, POST, PATCH, PUT, DELETE, OPTIONS\",\"strict-transport-security\":\"max-age=31536000\",\"via\":\"1.1 af4d78ee1727d0d18598a15bd2d1e4c4.cloudfront.net (CloudFront)\",\"access-control-expose-headers\":\"ETag, Twilio-Request-Id\",\"access-control-allow-origin\":\"*\",\"access-control-allow-credentials\":\"true\",\"x-powered-by\":\"AT-5000\",\"twilio-request-id\":\"RQ7087cdf0aabc61d5ba81f1a932d57889\",\"connection\":\"keep-alive\",\"content-type\":\"application/json;charset=utf-8\",\"x-cache\":\"Miss from cloudfront\",\"twilio-concurrent-requests\":\"1\",\"x-amz-cf-id\":\"sYFgtf6AKYTqvFzGO84rySK-ZcRjroMsm0Vv0KARTzyboUu0XPTPFQ==\"},\"hdr\":\"{\\\"x-amz-cf-pop\\\":\\\"BOM78-P4\\\",\\\"date\\\":\\\"Sat, 11 Jan 2025 19:03:01 GMT\\\",\\\"content-length\\\":\\\"777\\\",\\\"access-control-allow-headers\\\":\\\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\\\",\\\"x-shenanigans\\\":\\\"none\\\",\\\"x-api-domain\\\":\\\"api.twilio.com\\\",\\\"twilio-request-duration\\\":\\\"0.078\\\",\\\"x-home-region\\\":\\\"us1\\\",\\\"access-control-allow-methods\\\":\\\"GET, POST, PATCH, PUT, DELETE, OPTIONS\\\",\\\"strict-transport-security\\\":\\\"max-age=31536000\\\",\\\"via\\\":\\\"1.1 af4d78ee1727d0d18598a15bd2d1e4c4.cloudfront.net (CloudFront)\\\",\\\"access-control-expose-headers\\\":\\\"ETag, Twilio-Request-Id\\\",\\\"access-control-allow-origin\\\":\\\"*\\\",\\\"access-control-allow-credentials\\\":\\\"true\\\",\\\"x-powered-by\\\":\\\"AT-5000\\\",\\\"twilio-request-id\\\":\\\"RQ7087cdf0aabc61d5ba81f1a932d57889\\\",\\\"connection\\\":\\\"keep-alive\\\",\\\"content-type\\\":\\\"application/json;charset=utf-8\\\",\\\"x-cache\\\":\\\"Miss from cloudfront\\\",\\\"twilio-concurrent-requests\\\":\\\"1\\\",\\\"x-amz-cf-id\\\":\\\"sYFgtf6AKYTqvFzGO84rySK-ZcRjroMsm0Vv0KARTzyboUu0XPTPFQ==\\\"}\"}',NULL,'SM7087cdf0aabc61d5ba81f1a932d57889','queued','2025-01-12 00:33:04.079000'),('62bcd623-d90c-49fc-8dce-8bea697d1d16','c9d6c4d7-a055-43c6-8fec-a5153775f8df','5e42cf43-c4f2-4bce-9563-cc084c99145d','1','{\"statusCode\":201,\"responseText\":\"{\\\"account_sid\\\": \\\"AC1220ef95387e99127a04ae677fb9da92\\\", \\\"api_version\\\": \\\"2010-04-01\\\", \\\"body\\\": \\\"Hello World4\\\", \\\"date_created\\\": \\\"Sat, 11 Jan 2025 19:03:03 +0000\\\", \\\"date_sent\\\": null, \\\"date_updated\\\": \\\"Sat, 11 Jan 2025 19:03:03 +0000\\\", \\\"direction\\\": \\\"outbound-api\\\", \\\"error_code\\\": null, \\\"error_message\\\": null, \\\"from\\\": \\\"+15005550006\\\", \\\"messaging_service_sid\\\": null, \\\"num_media\\\": \\\"0\\\", \\\"num_segments\\\": \\\"1\\\", \\\"price\\\": null, \\\"price_unit\\\": \\\"USD\\\", \\\"sid\\\": \\\"SM7789fb94cb860804cf04c55d54ab565b\\\", \\\"status\\\": \\\"queued\\\", \\\"subresource_uris\\\": {\\\"media\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM7789fb94cb860804cf04c55d54ab565b/Media.json\\\"}, \\\"to\\\": \\\"+919987092183\\\", \\\"uri\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM7789fb94cb860804cf04c55d54ab565b.json\\\"}\",\"error\":false,\"json\":true,\"headers\":{\"x-amz-cf-pop\":\"BOM78-P4\",\"date\":\"Sat, 11 Jan 2025 19:03:03 GMT\",\"content-length\":\"777\",\"access-control-allow-headers\":\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\",\"x-shenanigans\":\"none\",\"x-api-domain\":\"api.twilio.com\",\"twilio-request-duration\":\"0.068\",\"x-home-region\":\"us1\",\"access-control-allow-methods\":\"GET, POST, PATCH, PUT, DELETE, OPTIONS\",\"strict-transport-security\":\"max-age=31536000\",\"via\":\"1.1 10bad5640499b6b4e82e61d8de4bb8d2.cloudfront.net (CloudFront)\",\"access-control-expose-headers\":\"ETag, Twilio-Request-Id\",\"access-control-allow-origin\":\"*\",\"access-control-allow-credentials\":\"true\",\"x-powered-by\":\"AT-5000\",\"twilio-request-id\":\"RQ7789fb94cb860804cf04c55d54ab565b\",\"connection\":\"keep-alive\",\"content-type\":\"application/json;charset=utf-8\",\"x-cache\":\"Miss from cloudfront\",\"twilio-concurrent-requests\":\"1\",\"x-amz-cf-id\":\"-iGgPVaPpqMBVqytDnVH3KBFnxrytB_fLO_f0SJAmyXyZjQk-lCONQ==\"},\"hdr\":\"{\\\"x-amz-cf-pop\\\":\\\"BOM78-P4\\\",\\\"date\\\":\\\"Sat, 11 Jan 2025 19:03:03 GMT\\\",\\\"content-length\\\":\\\"777\\\",\\\"access-control-allow-headers\\\":\\\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\\\",\\\"x-shenanigans\\\":\\\"none\\\",\\\"x-api-domain\\\":\\\"api.twilio.com\\\",\\\"twilio-request-duration\\\":\\\"0.068\\\",\\\"x-home-region\\\":\\\"us1\\\",\\\"access-control-allow-methods\\\":\\\"GET, POST, PATCH, PUT, DELETE, OPTIONS\\\",\\\"strict-transport-security\\\":\\\"max-age=31536000\\\",\\\"via\\\":\\\"1.1 10bad5640499b6b4e82e61d8de4bb8d2.cloudfront.net (CloudFront)\\\",\\\"access-control-expose-headers\\\":\\\"ETag, Twilio-Request-Id\\\",\\\"access-control-allow-origin\\\":\\\"*\\\",\\\"access-control-allow-credentials\\\":\\\"true\\\",\\\"x-powered-by\\\":\\\"AT-5000\\\",\\\"twilio-request-id\\\":\\\"RQ7789fb94cb860804cf04c55d54ab565b\\\",\\\"connection\\\":\\\"keep-alive\\\",\\\"content-type\\\":\\\"application/json;charset=utf-8\\\",\\\"x-cache\\\":\\\"Miss from cloudfront\\\",\\\"twilio-concurrent-requests\\\":\\\"1\\\",\\\"x-amz-cf-id\\\":\\\"-iGgPVaPpqMBVqytDnVH3KBFnxrytB_fLO_f0SJAmyXyZjQk-lCONQ==\\\"}\"}',NULL,'SM7789fb94cb860804cf04c55d54ab565b','queued','2025-01-12 00:33:05.369000'),('7047accf-e777-4a88-8271-ef131cb1dfde','fb3d8b33-5ef7-4bcb-a8db-01905b34f240','071d4b81-0564-4c66-9079-8492d221956e','1','{\"statusCode\":201,\"responseText\":\"{\\\"account_sid\\\": \\\"AC1220ef95387e99127a04ae677fb9da92\\\", \\\"api_version\\\": \\\"2010-04-01\\\", \\\"body\\\": \\\"Hello World3\\\", \\\"date_created\\\": \\\"Sat, 11 Jan 2025 19:03:02 +0000\\\", \\\"date_sent\\\": null, \\\"date_updated\\\": \\\"Sat, 11 Jan 2025 19:03:02 +0000\\\", \\\"direction\\\": \\\"outbound-api\\\", \\\"error_code\\\": null, \\\"error_message\\\": null, \\\"from\\\": \\\"+15005550006\\\", \\\"messaging_service_sid\\\": null, \\\"num_media\\\": \\\"0\\\", \\\"num_segments\\\": \\\"1\\\", \\\"price\\\": null, \\\"price_unit\\\": \\\"USD\\\", \\\"sid\\\": \\\"SMf08832ca7c4e2b64abc62a80e94afb01\\\", \\\"status\\\": \\\"queued\\\", \\\"subresource_uris\\\": {\\\"media\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SMf08832ca7c4e2b64abc62a80e94afb01/Media.json\\\"}, \\\"to\\\": \\\"+919987092183\\\", \\\"uri\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SMf08832ca7c4e2b64abc62a80e94afb01.json\\\"}\",\"error\":false,\"json\":true,\"headers\":{\"x-amz-cf-pop\":\"BOM78-P4\",\"date\":\"Sat, 11 Jan 2025 19:03:02 GMT\",\"content-length\":\"777\",\"access-control-allow-headers\":\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\",\"x-shenanigans\":\"none\",\"x-api-domain\":\"api.twilio.com\",\"twilio-request-duration\":\"0.039\",\"x-home-region\":\"us1\",\"access-control-allow-methods\":\"GET, POST, PATCH, PUT, DELETE, OPTIONS\",\"strict-transport-security\":\"max-age=31536000\",\"via\":\"1.1 306f9988120d2932240ba9b255b159ba.cloudfront.net (CloudFront)\",\"access-control-expose-headers\":\"ETag, Twilio-Request-Id\",\"access-control-allow-origin\":\"*\",\"access-control-allow-credentials\":\"true\",\"x-powered-by\":\"AT-5000\",\"twilio-request-id\":\"RQf08832ca7c4e2b64abc62a80e94afb01\",\"connection\":\"keep-alive\",\"content-type\":\"application/json;charset=utf-8\",\"x-cache\":\"Miss from cloudfront\",\"twilio-concurrent-requests\":\"1\",\"x-amz-cf-id\":\"4vbiBvgGUXKuuU26UlBlXO80epMBXQLSPBTGFUzR1-ij1bqIARYv5w==\"},\"hdr\":\"{\\\"x-amz-cf-pop\\\":\\\"BOM78-P4\\\",\\\"date\\\":\\\"Sat, 11 Jan 2025 19:03:02 GMT\\\",\\\"content-length\\\":\\\"777\\\",\\\"access-control-allow-headers\\\":\\\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\\\",\\\"x-shenanigans\\\":\\\"none\\\",\\\"x-api-domain\\\":\\\"api.twilio.com\\\",\\\"twilio-request-duration\\\":\\\"0.039\\\",\\\"x-home-region\\\":\\\"us1\\\",\\\"access-control-allow-methods\\\":\\\"GET, POST, PATCH, PUT, DELETE, OPTIONS\\\",\\\"strict-transport-security\\\":\\\"max-age=31536000\\\",\\\"via\\\":\\\"1.1 306f9988120d2932240ba9b255b159ba.cloudfront.net (CloudFront)\\\",\\\"access-control-expose-headers\\\":\\\"ETag, Twilio-Request-Id\\\",\\\"access-control-allow-origin\\\":\\\"*\\\",\\\"access-control-allow-credentials\\\":\\\"true\\\",\\\"x-powered-by\\\":\\\"AT-5000\\\",\\\"twilio-request-id\\\":\\\"RQf08832ca7c4e2b64abc62a80e94afb01\\\",\\\"connection\\\":\\\"keep-alive\\\",\\\"content-type\\\":\\\"application/json;charset=utf-8\\\",\\\"x-cache\\\":\\\"Miss from cloudfront\\\",\\\"twilio-concurrent-requests\\\":\\\"1\\\",\\\"x-amz-cf-id\\\":\\\"4vbiBvgGUXKuuU26UlBlXO80epMBXQLSPBTGFUzR1-ij1bqIARYv5w==\\\"}\"}',NULL,'SMf08832ca7c4e2b64abc62a80e94afb01','queued','2025-01-12 00:33:05.042000'),('8ff6038e-355c-463c-b785-e2749e05b2e9','38f50931-a8db-40d4-b635-a3fb56b23335','dfe6ea74-c5ce-461c-b413-a21ffcd246be','1','{\"statusCode\":201,\"responseText\":\"{\\\"account_sid\\\": \\\"AC1220ef95387e99127a04ae677fb9da92\\\", \\\"api_version\\\": \\\"2010-04-01\\\", \\\"body\\\": \\\"Hello World1\\\", \\\"date_created\\\": \\\"Sat, 11 Jan 2025 19:03:02 +0000\\\", \\\"date_sent\\\": null, \\\"date_updated\\\": \\\"Sat, 11 Jan 2025 19:03:02 +0000\\\", \\\"direction\\\": \\\"outbound-api\\\", \\\"error_code\\\": null, \\\"error_message\\\": null, \\\"from\\\": \\\"+15005550006\\\", \\\"messaging_service_sid\\\": null, \\\"num_media\\\": \\\"0\\\", \\\"num_segments\\\": \\\"1\\\", \\\"price\\\": null, \\\"price_unit\\\": \\\"USD\\\", \\\"sid\\\": \\\"SM33ea37f78a54034d5545b964b63f7284\\\", \\\"status\\\": \\\"queued\\\", \\\"subresource_uris\\\": {\\\"media\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM33ea37f78a54034d5545b964b63f7284/Media.json\\\"}, \\\"to\\\": \\\"+919987092183\\\", \\\"uri\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM33ea37f78a54034d5545b964b63f7284.json\\\"}\",\"error\":false,\"json\":true,\"headers\":{\"x-amz-cf-pop\":\"BOM78-P4\",\"date\":\"Sat, 11 Jan 2025 19:03:02 GMT\",\"content-length\":\"777\",\"access-control-allow-headers\":\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\",\"x-shenanigans\":\"none\",\"x-api-domain\":\"api.twilio.com\",\"twilio-request-duration\":\"0.065\",\"x-home-region\":\"us1\",\"access-control-allow-methods\":\"GET, POST, PATCH, PUT, DELETE, OPTIONS\",\"strict-transport-security\":\"max-age=31536000\",\"via\":\"1.1 10bad5640499b6b4e82e61d8de4bb8d2.cloudfront.net (CloudFront)\",\"access-control-expose-headers\":\"ETag, Twilio-Request-Id\",\"access-control-allow-origin\":\"*\",\"access-control-allow-credentials\":\"true\",\"x-powered-by\":\"AT-5000\",\"twilio-request-id\":\"RQ33ea37f78a54034d5545b964b63f7284\",\"connection\":\"keep-alive\",\"content-type\":\"application/json;charset=utf-8\",\"x-cache\":\"Miss from cloudfront\",\"twilio-concurrent-requests\":\"1\",\"x-amz-cf-id\":\"1dB6Ut8mCxEPh4zpplBz-QyP9fqbdhZnRxYyaVMteCYGN_LlpHeYpw==\"},\"hdr\":\"{\\\"x-amz-cf-pop\\\":\\\"BOM78-P4\\\",\\\"date\\\":\\\"Sat, 11 Jan 2025 19:03:02 GMT\\\",\\\"content-length\\\":\\\"777\\\",\\\"access-control-allow-headers\\\":\\\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\\\",\\\"x-shenanigans\\\":\\\"none\\\",\\\"x-api-domain\\\":\\\"api.twilio.com\\\",\\\"twilio-request-duration\\\":\\\"0.065\\\",\\\"x-home-region\\\":\\\"us1\\\",\\\"access-control-allow-methods\\\":\\\"GET, POST, PATCH, PUT, DELETE, OPTIONS\\\",\\\"strict-transport-security\\\":\\\"max-age=31536000\\\",\\\"via\\\":\\\"1.1 10bad5640499b6b4e82e61d8de4bb8d2.cloudfront.net (CloudFront)\\\",\\\"access-control-expose-headers\\\":\\\"ETag, Twilio-Request-Id\\\",\\\"access-control-allow-origin\\\":\\\"*\\\",\\\"access-control-allow-credentials\\\":\\\"true\\\",\\\"x-powered-by\\\":\\\"AT-5000\\\",\\\"twilio-request-id\\\":\\\"RQ33ea37f78a54034d5545b964b63f7284\\\",\\\"connection\\\":\\\"keep-alive\\\",\\\"content-type\\\":\\\"application/json;charset=utf-8\\\",\\\"x-cache\\\":\\\"Miss from cloudfront\\\",\\\"twilio-concurrent-requests\\\":\\\"1\\\",\\\"x-amz-cf-id\\\":\\\"1dB6Ut8mCxEPh4zpplBz-QyP9fqbdhZnRxYyaVMteCYGN_LlpHeYpw==\\\"}\"}',NULL,'SM33ea37f78a54034d5545b964b63f7284','queued','2025-01-12 00:33:04.425000'),('eda1d4e4-61f6-4ce4-acd1-cc4002033fc8','253db50e-8b33-466c-b912-9001e6670748','2c46ded5-2992-4329-a274-5f2ec4f59824','1','{\"statusCode\":201,\"responseText\":\"{\\\"account_sid\\\": \\\"AC1220ef95387e99127a04ae677fb9da92\\\", \\\"api_version\\\": \\\"2010-04-01\\\", \\\"body\\\": \\\"Hello World2\\\", \\\"date_created\\\": \\\"Sat, 11 Jan 2025 19:03:02 +0000\\\", \\\"date_sent\\\": null, \\\"date_updated\\\": \\\"Sat, 11 Jan 2025 19:03:02 +0000\\\", \\\"direction\\\": \\\"outbound-api\\\", \\\"error_code\\\": null, \\\"error_message\\\": null, \\\"from\\\": \\\"+15005550006\\\", \\\"messaging_service_sid\\\": null, \\\"num_media\\\": \\\"0\\\", \\\"num_segments\\\": \\\"1\\\", \\\"price\\\": null, \\\"price_unit\\\": \\\"USD\\\", \\\"sid\\\": \\\"SM8311f2b8083e1df9cc7a598e2d5d8024\\\", \\\"status\\\": \\\"queued\\\", \\\"subresource_uris\\\": {\\\"media\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM8311f2b8083e1df9cc7a598e2d5d8024/Media.json\\\"}, \\\"to\\\": \\\"+919987092183\\\", \\\"uri\\\": \\\"/2010-04-01/Accounts/AC1220ef95387e99127a04ae677fb9da92/Messages/SM8311f2b8083e1df9cc7a598e2d5d8024.json\\\"}\",\"error\":false,\"json\":true,\"headers\":{\"x-amz-cf-pop\":\"BOM78-P4\",\"date\":\"Sat, 11 Jan 2025 19:03:02 GMT\",\"content-length\":\"777\",\"access-control-allow-headers\":\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\",\"x-shenanigans\":\"none\",\"x-api-domain\":\"api.twilio.com\",\"twilio-request-duration\":\"0.066\",\"x-home-region\":\"us1\",\"access-control-allow-methods\":\"GET, POST, PATCH, PUT, DELETE, OPTIONS\",\"strict-transport-security\":\"max-age=31536000\",\"via\":\"1.1 fb6514ed0fa65e8962789d347bfecb50.cloudfront.net (CloudFront)\",\"access-control-expose-headers\":\"ETag, Twilio-Request-Id\",\"access-control-allow-origin\":\"*\",\"access-control-allow-credentials\":\"true\",\"x-powered-by\":\"AT-5000\",\"twilio-request-id\":\"RQ8311f2b8083e1df9cc7a598e2d5d8024\",\"connection\":\"keep-alive\",\"content-type\":\"application/json;charset=utf-8\",\"x-cache\":\"Miss from cloudfront\",\"twilio-concurrent-requests\":\"1\",\"x-amz-cf-id\":\"5q4O5-doNASu7cjOtAZazaZoUe4LwdMcJ3rUslpZZETcZ12JooKPXA==\"},\"hdr\":\"{\\\"x-amz-cf-pop\\\":\\\"BOM78-P4\\\",\\\"date\\\":\\\"Sat, 11 Jan 2025 19:03:02 GMT\\\",\\\"content-length\\\":\\\"777\\\",\\\"access-control-allow-headers\\\":\\\"Accept, Authorization, Content-Type, If-Match, If-Modified-Since, If-None-Match, If-Unmodified-Since, Idempotency-Key, X-Pre-Auth-Context, X-Target-Region\\\",\\\"x-shenanigans\\\":\\\"none\\\",\\\"x-api-domain\\\":\\\"api.twilio.com\\\",\\\"twilio-request-duration\\\":\\\"0.066\\\",\\\"x-home-region\\\":\\\"us1\\\",\\\"access-control-allow-methods\\\":\\\"GET, POST, PATCH, PUT, DELETE, OPTIONS\\\",\\\"strict-transport-security\\\":\\\"max-age=31536000\\\",\\\"via\\\":\\\"1.1 fb6514ed0fa65e8962789d347bfecb50.cloudfront.net (CloudFront)\\\",\\\"access-control-expose-headers\\\":\\\"ETag, Twilio-Request-Id\\\",\\\"access-control-allow-origin\\\":\\\"*\\\",\\\"access-control-allow-credentials\\\":\\\"true\\\",\\\"x-powered-by\\\":\\\"AT-5000\\\",\\\"twilio-request-id\\\":\\\"RQ8311f2b8083e1df9cc7a598e2d5d8024\\\",\\\"connection\\\":\\\"keep-alive\\\",\\\"content-type\\\":\\\"application/json;charset=utf-8\\\",\\\"x-cache\\\":\\\"Miss from cloudfront\\\",\\\"twilio-concurrent-requests\\\":\\\"1\\\",\\\"x-amz-cf-id\\\":\\\"5q4O5-doNASu7cjOtAZazaZoUe4LwdMcJ3rUslpZZETcZ12JooKPXA==\\\"}\"}',NULL,'SM8311f2b8083e1df9cc7a598e2d5d8024','queued','2025-01-12 00:33:04.751000');
/*!40000 ALTER TABLE `smsmessageresponses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessages`
--

DROP TABLE IF EXISTS `smsmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessages` (
  `SMId` varchar(50) NOT NULL,
  `SMAccId` bigint NOT NULL,
  `SMServiceName` varchar(255) NOT NULL,
  `SMInstanceName` varchar(50) NOT NULL,
  `SMRefId` varchar(50) NOT NULL,
  `SMTemplateId` varchar(255) DEFAULT NULL,
  `SMFrom` varchar(50) DEFAULT NULL,
  `SMToCountryCode` varchar(50) NOT NULL,
  `SMTo` varchar(50) NOT NULL,
  `SMProvince` varchar(50) DEFAULT NULL,
  `SMMessage` varchar(5000) NOT NULL,
  `SMLanguageCode` varchar(50) DEFAULT NULL,
  `SMStatus` int NOT NULL,
  `SMProviderStatus` int NOT NULL,
  `SMUtcSentTime` bigint DEFAULT NULL,
  `SMInternalStatus` int NOT NULL,
  `SMScheduledTimeUtc` bigint DEFAULT NULL,
  `SMReqId` varchar(50) DEFAULT NULL,
  `SMResId` varchar(50) DEFAULT NULL,
  `SMRetryCount` int NOT NULL DEFAULT '0',
  `SMCreatedAt` datetime(6) NOT NULL,
  `SMUpdatedAt` datetime(6) DEFAULT NULL,
  `SMLastUpdatedTime` bigint DEFAULT NULL,
  `SMErrorText` varchar(4000) DEFAULT NULL,
  `SMExtraData1` varchar(1000) DEFAULT NULL,
  `SMExtraData2` varchar(1000) DEFAULT NULL,
  `SMExtraData3` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`SMId`),
  UNIQUE KEY `idx_unq_acc_ref` (`SMAccId`,`SMRefId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessages`
--

LOCK TABLES `smsmessages` WRITE;
/*!40000 ALTER TABLE `smsmessages` DISABLE KEYS */;
INSERT INTO `smsmessages` VALUES ('253db50e-8b33-466c-b912-9001e6670748',1,'TWILIO','1','04ea6c32-e25e-4acd-8fc2-3bf5308f1ef7',NULL,'+15005550006',' ','919987092183','ON','Hello World2',NULL,2,1,NULL,0,NULL,'2c46ded5-2992-4329-a274-5f2ec4f59824','eda1d4e4-61f6-4ce4-acd1-cc4002033fc8',0,'2025-01-12 00:33:04.439000',NULL,NULL,NULL,'ACC1236','DP1',NULL),('38f50931-a8db-40d4-b635-a3fb56b23335',1,'TWILIO','1','4db9f883-715e-42cc-b7a2-9ec2f222c265',NULL,'+15005550006',' ','919987092183','ON','Hello World1',NULL,2,1,NULL,0,NULL,'dfe6ea74-c5ce-461c-b413-a21ffcd246be','8ff6038e-355c-463c-b785-e2749e05b2e9',0,'2025-01-12 00:33:04.115000',NULL,NULL,NULL,'ACC1235','DP1',NULL),('c9d6c4d7-a055-43c6-8fec-a5153775f8df',1,'TWILIO','1','343fe3bd-3355-46eb-83e4-a618c233ad11',NULL,'+15005550006',' ','919987092183','ON','Hello World4',NULL,2,1,NULL,0,NULL,'5e42cf43-c4f2-4bce-9563-cc084c99145d','62bcd623-d90c-49fc-8dce-8bea697d1d16',0,'2025-01-12 00:33:05.058000',NULL,NULL,NULL,'ACC1238','DP1',NULL),('e0a81c1c-7a30-423a-8ad3-b931d3071141',1,'TWILIO','1','6ca79b94-10d6-4a76-993d-70ab53643786',NULL,'+15005550006',' ','919987092183','ON','Hello World5',NULL,2,1,NULL,0,NULL,'5b74a935-15c5-44ff-aff4-c85de44f31d3','061f8dcc-a5db-4c42-aaf1-5fe713bb9735',0,'2025-01-12 00:33:05.382000',NULL,NULL,NULL,'ACC1239','DP1',NULL),('eb1fcbad-c4ba-4b91-b57a-7f0dfe7915bb',1,'TWILIO','1','2de56bf7-70b8-4245-8c91-84eeb97f8ca1',NULL,'+15005550006',' ','919987092183','ON','Hello World0',NULL,2,1,NULL,0,NULL,'6b21819b-69e6-4510-be06-dbb372cbf583','5cc12f50-8945-4084-9b15-f962e0b0d589',0,'2025-01-12 00:33:03.380000',NULL,NULL,NULL,'ACC1234','DP1',NULL),('fb3d8b33-5ef7-4bcb-a8db-01905b34f240',1,'TWILIO','1','e01512f6-d223-4c92-ade0-1f1c5d0db390',NULL,'+15005550006',' ','919987092183','ON','Hello World3',NULL,2,1,NULL,0,NULL,'071d4b81-0564-4c66-9079-8492d221956e','7047accf-e777-4a88-8271-ef131cb1dfde',0,'2025-01-12 00:33:04.764000',NULL,NULL,NULL,'ACC1237','DP1',NULL);
/*!40000 ALTER TABLE `smsmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessagesinbound`
--

DROP TABLE IF EXISTS `smsmessagesinbound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessagesinbound` (
  `SMINId` varchar(50) NOT NULL,
  `SMINMessageSid` varchar(255) DEFAULT NULL,
  `SMINFrom` varchar(50) NOT NULL,
  `SMINTo` varchar(50) NOT NULL,
  `SMINMessage` varchar(5000) NOT NULL,
  `SMINPayload1` varchar(5000) NOT NULL,
  `SMINPayload2` varchar(5000) DEFAULT NULL,
  `SMINCreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`SMINId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessagesinbound`
--

LOCK TABLES `smsmessagesinbound` WRITE;
/*!40000 ALTER TABLE `smsmessagesinbound` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsmessagesinbound` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessagetemplates`
--

DROP TABLE IF EXISTS `smsmessagetemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessagetemplates` (
  `SMTId` bigint NOT NULL AUTO_INCREMENT,
  `SMTAccId` bigint NOT NULL,
  `SMTActive` varchar(50) NOT NULL,
  `SMTCreatedAt` datetime(6) NOT NULL,
  `SMTData` varchar(5000) NOT NULL,
  `SMTLanguageCode` varchar(50) DEFAULT NULL,
  `SMTName` varchar(255) NOT NULL,
  `SMTUpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`SMTId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessagetemplates`
--

LOCK TABLES `smsmessagetemplates` WRITE;
/*!40000 ALTER TABLE `smsmessagetemplates` DISABLE KEYS */;
INSERT INTO `smsmessagetemplates` VALUES (1,1,'Y','2024-07-23 00:31:11.000000','ABC Farmacéutica Corporation','EN','message_EN',NULL),(2,1,'Y','2024-09-05 18:35:51.000000','ABC Farmacéutica Corporation','EN','en-CA',NULL);
/*!40000 ALTER TABLE `smsmessagetemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccounts`
--

DROP TABLE IF EXISTS `useraccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccounts` (
  `UAId` bigint NOT NULL,
  `UAName` varchar(255) NOT NULL,
  `UAStatus` varchar(2) NOT NULL,
  PRIMARY KEY (`UAId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccounts`
--

LOCK TABLES `useraccounts` WRITE;
/*!40000 ALTER TABLE `useraccounts` DISABLE KEYS */;
INSERT INTO `useraccounts` VALUES (1,'amexca','A');
/*!40000 ALTER TABLE `useraccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccounts_seq`
--

DROP TABLE IF EXISTS `useraccounts_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccounts_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccounts_seq`
--

LOCK TABLES `useraccounts_seq` WRITE;
/*!40000 ALTER TABLE `useraccounts_seq` DISABLE KEYS */;
INSERT INTO `useraccounts_seq` VALUES (1);
/*!40000 ALTER TABLE `useraccounts_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccountservices`
--

DROP TABLE IF EXISTS `useraccountservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccountservices` (
  `UASId` bigint NOT NULL,
  `UASInstanceId` bigint DEFAULT NULL,
  `UASServiceName` varchar(255) NOT NULL,
  `UASStatus` varchar(2) NOT NULL,
  `UASType` varchar(2) NOT NULL,
  `UASUaId` bigint NOT NULL,
  PRIMARY KEY (`UASId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccountservices`
--

LOCK TABLES `useraccountservices` WRITE;
/*!40000 ALTER TABLE `useraccountservices` DISABLE KEYS */;
INSERT INTO `useraccountservices` VALUES (1,1,'TWILIO','A','1',1);
/*!40000 ALTER TABLE `useraccountservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccountservices_seq`
--

DROP TABLE IF EXISTS `useraccountservices_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccountservices_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccountservices_seq`
--

LOCK TABLES `useraccountservices_seq` WRITE;
/*!40000 ALTER TABLE `useraccountservices_seq` DISABLE KEYS */;
INSERT INTO `useraccountservices_seq` VALUES (1);
/*!40000 ALTER TABLE `useraccountservices_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userroles`
--

DROP TABLE IF EXISTS `userroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userroles` (
  `URId` bigint NOT NULL AUTO_INCREMENT,
  `URUaId` bigint NOT NULL,
  `URROId` bigint NOT NULL,
  PRIMARY KEY (`URId`),
  KEY `userroles_roid_uaid` (`URUaId`,`URROId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroles`
--

LOCK TABLES `userroles` WRITE;
/*!40000 ALTER TABLE `userroles` DISABLE KEYS */;
INSERT INTO `userroles` VALUES (2,1,2),(3,2,3);
/*!40000 ALTER TABLE `userroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userserviceconfigurations`
--

DROP TABLE IF EXISTS `userserviceconfigurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userserviceconfigurations` (
  `USCId` bigint NOT NULL,
  `USCConfig` varchar(5000) NOT NULL,
  `USCServiceType` varchar(2) NOT NULL,
  `USCUaId` bigint NOT NULL,
  `USCUasId` bigint NOT NULL,
  `USCVendor` varchar(255) NOT NULL,
  PRIMARY KEY (`USCId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userserviceconfigurations`
--

LOCK TABLES `userserviceconfigurations` WRITE;
/*!40000 ALTER TABLE `userserviceconfigurations` DISABLE KEYS */;
INSERT INTO `userserviceconfigurations` VALUES (1,'{\"sid\" : \"AC1220ef95387e99127a04ae677fb9da92\",\"token\" : \"0cc0040aa0dbb3745315d89a00b18cf4\",\"phones\" : [\"+15005550006\"]}','1',1,1,'TWILIO');
/*!40000 ALTER TABLE `userserviceconfigurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userserviceconfigurations_seq`
--

DROP TABLE IF EXISTS `userserviceconfigurations_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userserviceconfigurations_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userserviceconfigurations_seq`
--

LOCK TABLES `userserviceconfigurations_seq` WRITE;
/*!40000 ALTER TABLE `userserviceconfigurations_seq` DISABLE KEYS */;
INSERT INTO `userserviceconfigurations_seq` VALUES (1);
/*!40000 ALTER TABLE `userserviceconfigurations_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'crssmsgateway'
--

--
-- Dumping routines for database 'crssmsgateway'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-14  0:07:27
