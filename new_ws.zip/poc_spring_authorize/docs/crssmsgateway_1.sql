-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: messaging
-- ------------------------------------------------------
-- Server version	8.4.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `crsallowedproviences`
--

DROP TABLE IF EXISTS `crsallowedproviences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crsallowedproviences` (
  `CAPId` bigint NOT NULL AUTO_INCREMENT,
  `CAPActive` varchar(1) NOT NULL,
  `CAPName` varchar(50) NOT NULL,
  PRIMARY KEY (`CAPId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crsallowedproviences`
--

LOCK TABLES `crsallowedproviences` WRITE;
/*!40000 ALTER TABLE `crsallowedproviences` DISABLE KEYS */;
INSERT INTO `crsallowedproviences` VALUES (1,'Y','ON');
/*!40000 ALTER TABLE `crsallowedproviences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crsproviencetimings`
--

DROP TABLE IF EXISTS `crsproviencetimings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crsproviencetimings` (
  `CPTId` bigint NOT NULL AUTO_INCREMENT,
  `CPTActive` varchar(1) NOT NULL,
  `CPTName` varchar(50) NOT NULL,
  `CPTTimeZone` varchar(50) NOT NULL,
  `CPTStartTimeMonday` varchar(8) DEFAULT NULL,
  `CPTEndTimeMonday` varchar(8) DEFAULT NULL,
  `CPTStartTimeTuesday` varchar(8) DEFAULT NULL,
  `CPTEndTimeTuesday` varchar(8) DEFAULT NULL,
  `CPTStartTimeWednesday` varchar(8) DEFAULT NULL,
  `CPTEndTimeWednesday` varchar(8) DEFAULT NULL,
  `CPTStartTimeThursday` varchar(8) DEFAULT NULL,
  `CPTEndTimeThursday` varchar(8) DEFAULT NULL,
  `CPTStartTimeFriday` varchar(8) DEFAULT NULL,
  `CPTEndTimeFriday` varchar(8) DEFAULT NULL,
  `CPTStartTimeSaturday` varchar(8) DEFAULT NULL,
  `CPTEndTimeSaturday` varchar(8) DEFAULT NULL,
  `CPTStartTimeSunday` varchar(8) DEFAULT NULL,
  `CPTEndTimeSunday` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`CPTId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crsproviencetimings`
--

LOCK TABLES `crsproviencetimings` WRITE;
/*!40000 ALTER TABLE `crsproviencetimings` DISABLE KEYS */;
INSERT INTO `crsproviencetimings` VALUES (1,'Y','DEFAULT','America/Toronto','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00',NULL,NULL),(2,'Y','ON','America/Toronto','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00','09:00:00','18:00:00',NULL,NULL);
/*!40000 ALTER TABLE `crsproviencetimings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessagerequests`
--

DROP TABLE IF EXISTS `smsmessagerequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessagerequests` (
  `SMRQId` varchar(50) NOT NULL,
  `SMRQSmId` varchar(50) NOT NULL,
  `SMRQPayload` varchar(5000) NOT NULL,
  `SMRQCreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`SMRQId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessagerequests`
--

LOCK TABLES `smsmessagerequests` WRITE;
/*!40000 ALTER TABLE `smsmessagerequests` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsmessagerequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessageresponses`
--

DROP TABLE IF EXISTS `smsmessageresponses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessageresponses` (
  `SMRSId` varchar(50) NOT NULL,
  `SMRSSmReqId` varchar(50) NOT NULL,
  `SMRSNumberOfMessages` varchar(2) DEFAULT NULL,
  `SMRSPayload` varchar(5000) NOT NULL,
  `SMRSServiceMsgId` varchar(255) DEFAULT NULL,
  `SMRSStatus` varchar(50) DEFAULT NULL,
  `SMRSCreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`SMRSId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessageresponses`
--

LOCK TABLES `smsmessageresponses` WRITE;
/*!40000 ALTER TABLE `smsmessageresponses` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsmessageresponses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessages`
--

DROP TABLE IF EXISTS `smsmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessages` (
  `SMId` varchar(50) NOT NULL,
  `SMAccId` bigint NOT NULL,
  `SMServiceName` varchar(255) NOT NULL,
  `SMInstanceName` varchar(50) NOT NULL,
  `SMRefId` varchar(50) NOT NULL,
  `SMTemplateId` varchar(255) DEFAULT NULL,
  `SMFrom` varchar(50) DEFAULT NULL,
  `SMToCountryCode` varchar(50) NOT NULL,
  `SMTo` varchar(50) NOT NULL,
  `SMProvince` varchar(50) DEFAULT NULL,
  `SMMessage` varchar(5000) NOT NULL,
  `SMLanguageCode` varchar(50) DEFAULT NULL,
  `SMStatus` int NOT NULL,
  `SMUtcSentTime` bigint DEFAULT NULL,
  `SMInternalStatus` int NOT NULL,
  `SMScheduledTimeUtc` bigint DEFAULT NULL,
  `SMReqId` varchar(50) DEFAULT NULL,
  `SMResId` varchar(50) DEFAULT NULL,
  `SMRetryCount` int NOT NULL DEFAULT '0',
  `SMCreatedAt` datetime(6) NOT NULL,
  `SMUpdatedAt` datetime(6) DEFAULT NULL,
  `SMLastUpdatedTime` bigint DEFAULT NULL,
  `SMExtraData1` varchar(1000) NULL,
  `SMExtraData2` varchar(1000) NULL,
  `SMExtraData3` varchar(1000) NULL,
  PRIMARY KEY (`SMId`),
  UNIQUE KEY `idx_unq_acc_ref` (`SMAccId`,`SMRefId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessages`
--

LOCK TABLES `smsmessages` WRITE;
/*!40000 ALTER TABLE `smsmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `smsmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smsmessagetemplates`
--

DROP TABLE IF EXISTS `smsmessagetemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `smsmessagetemplates` (
  `SMTId` bigint NOT NULL AUTO_INCREMENT,
  `SMTAccId` bigint NOT NULL,
  `SMTActive` varchar(50) NOT NULL,
  `SMTCreatedAt` datetime(6) NOT NULL,
  `SMTData` varchar(5000) NOT NULL,
  `SMTLanguageCode` varchar(50) DEFAULT NULL,
  `SMTName` varchar(255) NOT NULL,
  `SMTUpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`SMTId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smsmessagetemplates`
--

LOCK TABLES `smsmessagetemplates` WRITE;
/*!40000 ALTER TABLE `smsmessagetemplates` DISABLE KEYS */;
INSERT INTO `smsmessagetemplates` VALUES (1,1,'Y','2024-07-23 00:31:11.000000','ABC Farmacéutica Corporation','EN','message_EN',NULL),(2,1,'Y','2024-09-05 18:35:51.000000','ABC Farmacéutica Corporation','EN','en-CA',NULL);
/*!40000 ALTER TABLE `smsmessagetemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccounts`
--

DROP TABLE IF EXISTS `useraccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccounts` (
  `UAId` bigint NOT NULL,
  `UAName` varchar(255) NOT NULL,
  `UAStatus` varchar(2) NOT NULL,
  PRIMARY KEY (`UAId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccounts`
--

LOCK TABLES `useraccounts` WRITE;
/*!40000 ALTER TABLE `useraccounts` DISABLE KEYS */;
INSERT INTO `useraccounts` VALUES (1,'amex','A');
/*!40000 ALTER TABLE `useraccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccounts_seq`
--

DROP TABLE IF EXISTS `useraccounts_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccounts_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccounts_seq`
--

LOCK TABLES `useraccounts_seq` WRITE;
/*!40000 ALTER TABLE `useraccounts_seq` DISABLE KEYS */;
INSERT INTO `useraccounts_seq` VALUES (1);
/*!40000 ALTER TABLE `useraccounts_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccountservices`
--

DROP TABLE IF EXISTS `useraccountservices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccountservices` (
  `UASId` bigint NOT NULL,
  `UASInstanceId` bigint DEFAULT NULL,
  `UASServiceName` varchar(255) NOT NULL,
  `UASStatus` varchar(2) NOT NULL,
  `UASType` varchar(2) NOT NULL,
  `UASUaId` bigint NOT NULL,
  PRIMARY KEY (`UASId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccountservices`
--

LOCK TABLES `useraccountservices` WRITE;
/*!40000 ALTER TABLE `useraccountservices` DISABLE KEYS */;
INSERT INTO `useraccountservices` VALUES (1,1,'TWILIO','A','1',1);
/*!40000 ALTER TABLE `useraccountservices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccountservices_seq`
--

DROP TABLE IF EXISTS `useraccountservices_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useraccountservices_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccountservices_seq`
--

LOCK TABLES `useraccountservices_seq` WRITE;
/*!40000 ALTER TABLE `useraccountservices_seq` DISABLE KEYS */;
INSERT INTO `useraccountservices_seq` VALUES (1);
/*!40000 ALTER TABLE `useraccountservices_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apiuserauthconfigs`
--

DROP TABLE IF EXISTS `apiuserauthconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apiuserauthconfigs` (
  `UACId` bigint NOT NULL AUTO_INCREMENT,
  `UACUaId` bigint NOT NULL,
  `UACType` varchar(2) NOT NULL,
  `UACStatus` varchar(2) NOT NULL,
  `UACConfig` varchar(5000) NOT NULL,
  `UACUserName` varchar(5000) NULL,
  `UACPassword` varchar(5000) NULL,
  PRIMARY KEY (`UACId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apiuserauthconfigs`
--

LOCK TABLES `apiuserauthconfigs` WRITE;
/*!40000 ALTER TABLE `apiuserauthconfigs` DISABLE KEYS */;
INSERT INTO `apiuserauthconfigs` VALUES (1,1,'1','A','{\"pubKey\":\"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzAuG+5oOmJUMiI4GN8tGxJsPk74faOJWHoxf/J6CH2v5eM3T/6zGf/eyiwTSh1qse+hHrW3NDCEdO7ROQ+St2P0HlhDrwH/eVURg+P2iDaP1vNCQxdQ0GeyN7yhkHWVIAQU03Lxu0FN0uVVa82lwH2sVXr6qQZP6neDHkuLuE2mmSZntrVjEerPvQ5uL5zp4PQhhHIvV/DMTQ0aAk3Dyx6OMVs5w0uELTGfzkSKynGrJO0TjhucO0XzFRM2kyhe4D6Uku4QCiP7OPdQs0ysJy3YGK1zGGV6U/+YGLM5mFJeFxDGR5NdAiTNIx5tWh4HAHDcvY0bPECgzP3P4y815XQIDAQAB\"}', null, null);
/*!40000 ALTER TABLE `apiuserauthconfigs` ENABLE KEYS */;
UNLOCK TABLES;



--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `ROId` bigint NOT NULL AUTO_INCREMENT,
  `ROName` varchar(100) NOT NULL,
  PRIMARY KEY (`ROId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actions` (
  `ACId` bigint NOT NULL AUTO_INCREMENT,
  `ACAction` varchar(100) NOT NULL,
  PRIMARY KEY (`ACId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

--
-- Table structure for table `roleactions`
--

DROP TABLE IF EXISTS `roleactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roleactions` (
  `RAId` bigint NOT NULL AUTO_INCREMENT,
  `RAROId` bigint NOT NULL,
  `RAACId` bigint NOT NULL,
  PRIMARY KEY (`RAId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roleactions`
--

--
-- Table structure for table `userroles`
--

DROP TABLE IF EXISTS `userroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userroles` (
  `URId` bigint NOT NULL AUTO_INCREMENT,
  `URUaId` bigint NOT NULL,
  `URROId` bigint NOT NULL,
  PRIMARY KEY (`URId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userroles`
--

--
-- Table structure for table `userserviceconfigurations`
--

DROP TABLE IF EXISTS `userserviceconfigurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userserviceconfigurations` (
  `USCId` bigint NOT NULL,
  `USCConfig` varchar(5000) NOT NULL,
  `USCServiceType` varchar(2) NOT NULL,
  `USCUaId` bigint NOT NULL,
  `USCUasId` bigint NOT NULL,
  `USCVendor` varchar(255) NOT NULL,
  PRIMARY KEY (`USCId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userserviceconfigurations`
--

LOCK TABLES `userserviceconfigurations` WRITE;
/*!40000 ALTER TABLE `userserviceconfigurations` DISABLE KEYS */;
INSERT INTO `userserviceconfigurations` VALUES (1,'{\"sid\" : \"AC1220ef95387e99127a04ae677fb9da92\",\"token\" : \"0cc0040aa0dbb3745315d89a00b18cf4\",\"phones\" : [\"+15005550006\"]}','1',1,1,'TWILIO');
/*!40000 ALTER TABLE `userserviceconfigurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userserviceconfigurations_seq`
--

DROP TABLE IF EXISTS `userserviceconfigurations_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userserviceconfigurations_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userserviceconfigurations_seq`
--

LOCK TABLES `userserviceconfigurations_seq` WRITE;
/*!40000 ALTER TABLE `userserviceconfigurations_seq` DISABLE KEYS */;
INSERT INTO `userserviceconfigurations_seq` VALUES (1);
/*!40000 ALTER TABLE `userserviceconfigurations_seq` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-21 20:18:28
