
    create table AmexAllowedProviences (
        AAPId bigint not null auto_increment,
        AAPActive varchar(1) not null,
        AAPName varchar(50) not null,
        primary key (AAPId)
    ) engine=InnoDB;

    create table AmexProvienceTimings (
        APTId bigint not null auto_increment,
        APTActive varchar(1) not null,
        APTEndTimeFriday varchar(8),
        APTEndTimeMonday varchar(8),
        APTEndTimeSaturday varchar(8),
        APTEndTimeSunday varchar(8),
        APTEndTimeThursday varchar(8),
        APTEndTimeTuesday varchar(8),
        APTEndTimeWednesday varchar(8),
        APTName varchar(50) not null,
        APTStartTimeFriday varchar(8),
        APTStartTimeMonday varchar(8),
        APTStartTimeSaturday varchar(8),
        APTStartTimeSunday varchar(8),
        APTStartTimeThursday varchar(8),
        APTStartTimeTuesday varchar(8),
        APTStartTimeWednesday varchar(8),
        APTTimeZone varchar(50) not null,
        primary key (APTId)
    ) engine=InnoDB;

    create table SmsMessageRequests (
        SMRQId varchar(50) not null,
        SMRQCreatedAt datetime(6) not null,
        SMRQPayload varchar(5000) not null,
        SMRQSmId varchar(50) not null,
        primary key (SMRQId)
    ) engine=InnoDB;

    create table SmsMessageResponses (
        SMRSId varchar(50) not null,
        SMRSCreatedAt datetime(6) not null,
        SMRSNumberOfMessages varchar(2),
        SMRSPayload varchar(5000) not null,
        SMRSServiceMsgId varchar(255),
        SMRSStatus varchar(50),
        SMRSSmReqId varchar(50) not null,
        primary key (SMRSId)
    ) engine=InnoDB;

    create table SmsMessages (
        SMId varchar(50) not null,
        SMAccId bigint not null,
        SMCreatedAt datetime(6) not null,
        SMFrom varchar(50),
        SMLanguageCode varchar(50),
        SMInstanceName varchar(50) not null,
        SMInternalStatus integer not null,
        SMLastUpdatedTime bigint,
        SMMessage varchar(5000) not null,
        SMProvince varchar(50),
        SMRefId varchar(50) not null,
        SMScheduledTimeUtc bigint,
        SMServiceName varchar(255) not null,
        SMReqId varchar(50),
        SMResId varchar(50),
        SMStatus integer not null,
        SMTemplateId varchar(255),
        SMTo varchar(50) not null,
        SMToCountryCode varchar(50) not null,
        SMUpdatedAt datetime(6),
        SMUtcSentTime bigint,
        primary key (SMId)
    ) engine=InnoDB;

    create table SmsMessageTemplates (
        SMTId bigint not null auto_increment,
        SMTAccId bigint not null,
        SMTActive varchar(50) not null,
        SMTCreatedAt datetime(6) not null,
        SMTData varchar(5000) not null,
        SMTLanguageCode varchar(50),
        SMTName varchar(255) not null,
        SMTUpdatedAt datetime(6),
        primary key (SMTId)
    ) engine=InnoDB;

    create table UserAccounts (
        UAId bigint not null,
        UAName varchar(255) not null,
        UAStatus varchar(2) not null,
        primary key (UAId)
    ) engine=InnoDB;

    create table UserAccounts_SEQ (
        next_val bigint
    ) engine=InnoDB;

    insert into UserAccounts_SEQ values ( 1 );

    create table UserAccountServices (
        UASId bigint not null,
        UASInstanceId bigint,
        UASServiceName varchar(255) not null,
        UASStatus varchar(2) not null,
        UASType varchar(2) not null,
        UASUaId bigint not null,
        primary key (UASId)
    ) engine=InnoDB;

    create table UserAccountServices_SEQ (
        next_val bigint
    ) engine=InnoDB;

    insert into UserAccountServices_SEQ values ( 1 );

    create table UserServiceConfigurations (
        USCId bigint not null,
        USCConfig varchar(5000) not null,
        USCServiceType varchar(2) not null,
        USCUaId bigint not null,
        USCUasId bigint not null,
        USCVendor varchar(255) not null,
        primary key (USCId)
    ) engine=InnoDB;

    create table UserServiceConfigurations_SEQ (
        next_val bigint
    ) engine=InnoDB;

    insert into UserServiceConfigurations_SEQ values ( 1 );

    alter table SmsMessageTemplates 
       add constraint UKpeio59e1cs355gq6fx39droui unique (SMTAccId);
