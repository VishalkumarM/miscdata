function l(o,i){const e=[];let t=o;for(;t!=null&&t.kind;)e.push(t),t=t.prevState;for(let a=e.length-1;a>=0;a--)i(e[a])}export{l as f};
