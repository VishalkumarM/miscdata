package com.mysample.j2ee;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.ResourceBundle;

public class ConfigUtil {
	
//	private ConfigUtil() {
//        throw new IllegalStateException("Utility class");
//    }

    private static final Properties properties = new Properties();

    static {
        try (InputStream input = ConfigUtil.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) {
                throw new RuntimeException("Configuration file not found in classpath!");
            }
            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load configuration file", e);
        }
    }
    
    private static final ResourceBundle resourceBundle = ResourceBundle.getBundle("config"); // No .properties in name!

    public static String getProperty(String key) {
        return resourceBundle.getString(key);
    }

//    public static String getProperty(String key) {
//        return properties.getProperty(key);
//    }
}
