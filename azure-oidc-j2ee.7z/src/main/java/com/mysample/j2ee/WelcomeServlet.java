package com.mysample.j2ee;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import groovy.json.JsonSlurper;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/welcome")
public class WelcomeServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 5859366607610958009L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idToken = getIdTokenFromCookie(request);

        if (idToken == null) {
            response.getWriter().write("No ID Token found. Please <a href='/login'>login</a> again.");
            return;
        }

        Map<String, Object> userInfo = decodeJwt(idToken);
        String name = (String) userInfo.getOrDefault("name", "Unknown User");
        String email = (String) userInfo.getOrDefault("email", "No Email");

        response.getWriter().write("<h1>Welcome, " + name + "!</h1>");
        response.getWriter().write("<p>Email: " + email + "</p>");
        response.getWriter().write("<a href='logout'>Logout</a>");
    }

    private String getIdTokenFromCookie(HttpServletRequest request) {
        if (request.getCookies() != null) {
            for (jakarta.servlet.http.Cookie cookie : request.getCookies()) {
                if (cookie.getName().equals("id_token")) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
	private Map<String, Object> decodeJwt(String jwt) {
        String[] parts = jwt.split("\\.");
        if (parts.length < 2) return new HashMap<>();

        String payload = new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8);
        return (Map<String, Object>) new JsonSlurper().parseText(payload);
    }
}
