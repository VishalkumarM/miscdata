package com.mysample.j2ee.implicit;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

import com.mysample.j2ee.ConfigUtil;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login_implicit")
public class OIDCLoginServletImplicit extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1455849997877178891L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String clientId = ConfigUtil.getProperty("azure.client.id");
        String redirectUri = ConfigUtil.getProperty("azure.redirect.uri_implicit");
        String scope = ConfigUtil.getProperty("azure.scope");

        String state = UUID.randomUUID().toString(); // Prevent CSRF
        request.getSession().setAttribute("oauthState", state);

        String authUrl = ConfigUtil.getProperty("azure.token.endpoint") +
                "?client_id=" + clientId +
                "&response_type=id_token" +  // Implicit Grant requests an ID Token directly
                "&redirect_uri=" + URLEncoder.encode(redirectUri, StandardCharsets.UTF_8) +
                "&scope=" + URLEncoder.encode(scope, StandardCharsets.UTF_8) +
                "&nonce=" + UUID.randomUUID().toString() +  // Prevent replay attacks
                "&state=" + state;

        response.sendRedirect(authUrl);
    }
}
