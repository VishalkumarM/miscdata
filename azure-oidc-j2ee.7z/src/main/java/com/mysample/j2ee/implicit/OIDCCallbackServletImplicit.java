package com.mysample.j2ee.implicit;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/callback_implicit")
public class OIDCCallbackServletImplicit extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = -7275619681130460956L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Azure AD returns ID Token in the fragment, not query params.
        response.setContentType("text/html");

        response.getWriter().write("<script>" +
                "const params = new URLSearchParams(window.location.hash.substring(1));" + 
                "const idToken = params.get('id_token');" +
                "if (idToken) {" +
                "   document.cookie = 'id_token=' + idToken + '; path=/';" + 
                "   window.location.href = 'welcome';" +
                "} else {" +
                "   document.body.innerHTML = 'Error: No ID Token received.';" +
                "}" +
                "</script>");
    }
}