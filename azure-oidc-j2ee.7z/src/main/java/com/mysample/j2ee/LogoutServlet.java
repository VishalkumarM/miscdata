package com.mysample.j2ee;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = -2122448985315721779L;

	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Remove cookie
        jakarta.servlet.http.Cookie idTokenCookie = new jakarta.servlet.http.Cookie("id_token", "");
        idTokenCookie.setPath("/");
        idTokenCookie.setMaxAge(0);
        response.addCookie(idTokenCookie);

        // Redirect to Azure AD logout
        String tenantId = ConfigUtil.getProperty("azure.tenant.id");
        response.sendRedirect("https://login.microsoftonline.com/" + tenantId + "/oauth2/logout");
    }
}