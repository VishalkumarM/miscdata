package com.mysample.j2ee.auth;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import com.mysample.j2ee.ConfigUtil;

import groovy.json.JsonSlurper;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/callback")
public class OIDCCallbackServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1939501581651991051L;

	@Override
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Enumeration<String> reqrequest = request.getParameterNames();
		while (reqrequest.hasMoreElements()) {
			String paramName = reqrequest.nextElement();
			String paramValue = request.getParameter(paramName);
			System.out.println("Parameter Name: " + paramName + ", Parameter Value: " + paramValue);
		}
		
        String code = request.getParameter("code");
        String state = request.getParameter("state");

        // Validate state (Optional security step)
        String sessionState = (String) request.getSession().getAttribute("oauthState");
        if (sessionState == null || !sessionState.equals(state)) {
            response.getWriter().write("Invalid state parameter!");
            return;
        }
        
        String tenantId = ConfigUtil.getProperty("azure.tenant.id");
        String clientId = ConfigUtil.getProperty("azure.client.id");
        String redirectUri = ConfigUtil.getProperty("azure.redirect.uri");
        String clientSecret = ConfigUtil.getProperty("azure.client.secret");
        String tokenEndpoint = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";
        

        Map<String, String> parameters = new HashMap<>();
        parameters.put("client_id", clientId);
        parameters.put("client_secret", clientSecret);
        parameters.put("code", code);
        parameters.put("redirect_uri", redirectUri);
        parameters.put("grant_type", "authorization_code");

        String tokenResponse = sendPostRequest(tokenEndpoint, parameters);
        Map<String, Object> jsonResponse = (Map<String, Object>) new JsonSlurper().parseText(tokenResponse);
        System.out.println("Token Response :: " + tokenResponse);
        // Extract ID Token (JWT)
        String idToken = (String) jsonResponse.get("id_token");

        response.getWriter().write("ID Token: " + idToken);
    }

    private String sendPostRequest(String url, Map<String, String> params) throws IOException {
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        StringBuilder postData = new StringBuilder();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (postData.length() != 0) postData.append('&');
            postData.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            postData.append('=');
            postData.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        con.setDoOutput(true);
        try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
            wr.writeBytes(postData.toString());
            wr.flush();
        }

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        return response.toString();
    }
}
