package com.mysample.j2ee.auth;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.UUID;

import com.mysample.j2ee.ConfigUtil;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class OIDCLoginServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = -7990974053271516554L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String clientId = ConfigUtil.getProperty("azure.client.id");
        String redirectUri = ConfigUtil.getProperty("azure.redirect.uri");
        String scope = ConfigUtil.getProperty("azure.scope");
        
        String state = UUID.randomUUID().toString(); // Random state for security

        String authorizationUrl = ConfigUtil.getProperty("azure.auth.endpoint") + //"https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/authorize" +
                "?client_id=" + clientId +
                "&response_type=code" +
                "&redirect_uri=" + URLEncoder.encode(redirectUri, "UTF-8") +
                "&scope=" + URLEncoder.encode(scope, "UTF-8") +
                "&state=" + state;
        
        System.out.println("authorizationUrl :: " + authorizationUrl);

        request.getSession().setAttribute("oauthState", state);
        response.sendRedirect(authorizationUrl);
    }
}